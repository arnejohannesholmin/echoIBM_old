#*********************************************
#*********************************************
#' Transforms points in the global coordinate system of Earth, given in longitude, latitude and heave decimal values (DD) in the range [-180,180] for longitude (East) and [-90,90] for latitude (North), to a cartesian coordinate system centered at a reference position, with y-axis pointing North and z-axis pointing vertically outwards from the surface of the Earth. Circular surface of the Earth is assumed in a neighbourhood around the 'origin'.
#'
#' @param pos  is a list, matrix or vector of the points to be transformed, given in longitude-latitude-heave decimal values (DD).
#' @param origin  can be one of two objects: (1) A vector of length 3 holding the origin of the cartesian coordinate system, given in longitude-latitude-heave decimal values (DD). (2) an integer giving which point to pick from 'pos' as the origin (origin=4 gives origin=pos[4,]).
#' @param list.out  is TRUE if the output should be put in a list.
#'
#' @return
#'
#' @examples
#' \dontrun{}
#'
#' @export
#' @rdname global2car
#'
global2car<-function(pos, origin=1, list.out=FALSE){
	
	############ AUTHOR(S): ############
	# Arne Johannes Holmin
	############ LANGUAGE: #############
	# English
	############### LOG: ###############
	# Start: 2009-07-23 - Clean version.
	# Update: 2010-02-20 - Added support for TSD input.
	# Last: 2010-06-09 - Removed data.frame output reducing CPU time to 75 %.
	########### DESCRIPTION: ###########
	# Transforms points in the global coordinate system of Earth, given in longitude, latitude and heave decimal values (DD) in the range [-180,180] for longitude (East) and [-90,90] for latitude (North), to a cartesian coordinate system centered at a reference position, with y-axis pointing North and z-axis pointing vertically outwards from the surface of the Earth. Circular surface of the Earth is assumed in a neighbourhood around the 'origin'.
	########## DEPENDENCIES: ###########
	# zeros(), radiusEarth()
	############ VARIABLES: ############
	# ---pos--- is a list, matrix or vector of the points to be transformed, given in longitude-latitude-heave decimal values (DD).
	# ---origin--- can be one of two objects: (1) A vector of length 3 holding the origin of the cartesian coordinate system, given in longitude-latitude-heave decimal values (DD). (2) an integer giving which point to pick from 'pos' as the origin (origin=4 gives origin=pos[4,]).
	# ---list.out--- is TRUE if the output should be put in a list.
	
	
	##################################################
	##################################################
	##### Preparation #####
	# Support for list, matrix and vector input for 'pos':
	# List:
	if(is.list(pos)){
		namespos=names(pos)=tolower(names(pos))
		# 'origin' given in the list:
		if(!any(is.null(pos$lon0),is.null(pos$lat0))){
			origin=c(pos$lon0[1],pos$lat0[1],0)
			}
		
		# 'pos' given in the list:
		hitslon=grep("lon",namespos)
		hitslat=grep("lat",namespos)
		# If non-unique names are present in the list:
		if(any(length(hitslon)>1,length(hitslat)>1)){
			warning(paste("More than one set of 'lon*' and 'lat*' values. Selecting '",namespos[hitslon[1]],"' and '",namespos[hitslat[1]],"'",sep=""))
			}
		if(all(length(hitslon)>0,length(hitslat)>0)){
			if(!is.null(pos$psz)){
				pos=cbind(pos[[namespos[hitslon[1]]]],pos[[namespos[hitslat[1]]]],pos$psz)
				}
			else if(!is.null(pos$heav)){
				pos=cbind(pos[[namespos[hitslon[1]]]],pos[[namespos[hitslat[1]]]],pos$heav)
				}
			# Heave need not be given defaulting to 0:
			else{
				pos=cbind(pos[[namespos[hitslon[1]]]],pos[[namespos[hitslat[1]]]],0)
				}
			}
		# If names for longitude, latitude and heave (optional) are not given, [[1]] is interpreted as 'longitude', [[2]] is interpreted as 'latitude' and [[3]] is if present interpreted as 'heave'.
		else if(length(pos)>2){
			warning("First three list elements used as global coordinates")
			pos=cbind(pos[[1]],pos[[2]],pos[[3]])
			}
		else if(length(pos)>1){
			warning("First two list elements used as global coordinates")
			pos=cbind(pos[[1]],pos[[2]],0)
			}
		else{
			stop("Longitude AND latitude must be given (heave may be defaulted to 0)")
			}
		}
	dimpos=dim(pos)
	# Matrix:
	if(length(dimpos)==2 && ncol(pos)<3){
		pos=cbind(pos,zeros(nrow(pos),3-ncol(pos)))
		}
	# Vector:
	else if(is.null(dimpos) && length(pos) %in% 1:3){
		pos=t(c(pos,double(3-length(pos))))
		}
	else if(length(dimpos)!=2){
		return(NULL)
		}
	# If origin is an integer in the range [1,nrow(pos)], the point pos[origin] is regarded as the 'origin':
	if(is.list(origin)){
		if(all(!is.null(origin$lon),!is.null(origin$lat))){
			origin=c(origin$lon,origin$lat)
			}
		else{
			origin=c(origin[[1]],origin[[2]])
			}
		}
	origin=as.numeric(origin)
	# 'origin' must be a vector of length 3, or an integer specifying which global position to regard as the origin:
	lorigin=length(origin)
	if(lorigin==2){
		origin=c(origin,0)
		}
	else if(lorigin==1 && origin %in% 1:nrow(pos)){
		origin=pos[origin,]
		}
	else if(lorigin<2){
		warning("'origin' defaulted to the first position")
		origin=pos[1,]
		}
		
		
	##### Execution and output #####
	# The difference between 'pos' and 'origin' transformed to radians is mutiplied by the circumference of the Earth zonal in the x-direction and meridional in the y-direction. The z-diretion is already in meters:
	pos[,1]=(pos[,1]-origin[1])*pi/180*radiusEarth(pos[,2],toaxis=TRUE)
	pos[,2]=(pos[,2]-origin[2])*pi/180*radiusEarth(pos[,2])
	pos[,3]=pos[,3]-origin[3]
	colnames(pos)=c("x","y","z")
	# If list output is required:
	if(list.out){
		list(x=out[,1],y=out[,2],z=out[,3])
		}
	else{
		pos
		}
	##################################################
	##################################################
	}
