#*********************************************
#*********************************************
#' Calculating the radius of Earth for the given latitude value(s).
#'
#' @param lat  is a vector of latitude values.
#' @param toaxis  is TRUE if the radius to the axis of Earth is to be given.
#'
#' @return
#'
#' @examples
#' \dontrun{}
#'
#' @export
#' @rdname radiusEarth
#'
radiusEarth<-function(lat,toaxis=FALSE){
	
	############ AUTHOR(S): ############
	# Arne Johannes Holmin
	############ LANGUAGE: #############
	# English
	############### LOG: ###############
	# Start: 2008-02-25 - Clean version.
	# Last:  2009-08-18 - Simplified.
	########### DESCRIPTION: ###########
	# Calculating the radius of Earth for the given latitude value(s).
	########## DEPENDENCIES: ###########
	#
	############ VARIABLES: ############
	# ---lat--- is a vector of latitude values.
	# ---toaxis--- is TRUE if the radius to the axis of Earth is to be given.
	
	
	##################################################
	##################################################
	##### Preparation #####
	# From wikipedia through "http://earth-info.nga.mil/GandG/publications/tr8350.2/wgs84fin.pdf":
	# Equatorial radius:
	a=6378137.0
	# Polar radius:
	b=6356752.3
	# Transform input latitude to radians:
	lat=lat/180*pi
	
	
	##### Execution and output #####
	# Numeric exentricity:
	epsilon<-sqrt(a^2-b^2)/a
	# Radius given 'lat':
	r=sqrt(b^2/(1-epsilon^2*(cos(lat))^2))
	if(toaxis){
		r*cos(lat)
		}
	else{
		r
		}
	##################################################
	##################################################
	}
