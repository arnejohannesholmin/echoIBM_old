#*********************************************
#*********************************************
#' Transforms Windows FILETIME to UNIX time.
#'
#' @param x  are the time points given in Windows FILETIME format (the number of 100 nanoseconds since 1 January 1601).
#' @param xBase  is the base of Windows FILETIME: xBase=unclass(as.POSIXct('1601-1-1', tz="UTC"))[1].
#' @param tz  is the the time zone. Overrides 'xBase' if not given as tz="UTC". See as.POSIXlt().
#'
#' @return
#'
#' @examples
#' \dontrun{}
#'
#' @export
#' @rdname FILETIME2utim
#'
FILETIME2utim<-function(x, xBase=-11644473600, tz="UTC"){
	
	############ AUTHOR(S): ############
	# Arne Johannes Holmin
	############ LANGUAGE: #############
	# English
	############### LOG: ###############
	# Start: 2011-11-09 - Clean version.
	########### DESCRIPTION: ###########
	# Transforms Windows FILETIME to UNIX time.
	########## DEPENDENCIES: ###########
	#
	############ VARIABLES: ############
	# ---x--- are the time points given in Windows FILETIME format (the number of 100 nanoseconds since 1 January 1601).
	# ---xBase--- is the base of Windows FILETIME: xBase=unclass(as.POSIXct('1601-1-1', tz="UTC"))[1].
	# ---tz--- is the the time zone. Overrides 'xBase' if not given as tz="UTC". See as.POSIXlt().
	
	
	##################################################
	##################################################
	##### Preparation #####
	if(!tz=="UTC"){
		xBase=unclass(as.POSIXct('1601-1-1', tz=tz))[1]
		}
	# Convert to seconds:
	x.sec=as.numeric(x)*1e-7
	
	##### Execution and output #####
	x.sec+xBase
   	##################################################
	##################################################
	}
