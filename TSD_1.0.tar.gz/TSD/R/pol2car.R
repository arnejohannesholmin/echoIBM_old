#*********************************************
#*********************************************
#' Transformation from polar coordinates given as 'r' and 'theta', to cartesian coordinates.
#'
#' @param r  represents the points to transform, structured in one of the 4 following ways:
#' @param theta  is a vector of theta-values (optional).
#' @param perm  is TRUE if the input points 'r' are given as a row matrix (see 'r').
#' @param list.out  is TRUE if the output should be put in a list.
#'
#' @return
#'
#' @examples
#' \dontrun{}
#'
#' @export
#' @rdname pol2car
#'
pol2car<-function(r,theta=NULL,perm=FALSE,list.out=FALSE){
	
	############ AUTHOR(S): ############
	# Arne Johannes Holmin
	############ LANGUAGE: #############
	# English
	############### LOG: ###############
	# Start: 2008-03-11 - Finished.
	# Update:  2009-03-08 - Changed input to more robust.
	# Update:  2009-07-28 - Removed input variable 'drop.out'. Added support for list input and changed interpretation of 'r' and 'theta' so that if is.null(theta) and 'r' is a vector or a single column matrix, then theta=0.
	# Update:  2010-06-02 - Function altered to returning the output at each case of the input. Also added the option 'perm', allowing for row matrices. All in all reducing CPU time to 70 %.
	# Update:  2010-06-09 - One option added: 'list.out' (see VARIABLES). CPU time reduction to 100 %.
	# Last:  2010-08-27 - Replaced data frame output by list output.
	########### DESCRIPTION: ###########
	# Transformation from polar coordinates given as 'r' and 'theta', to cartesian coordinates.
	########## DEPENDENCIES: ###########
	#
	############ VARIABLES: ############
	# ---r--- represents the points to transform, structured in one of the 4 following ways:
	#		(1) is either a vector of 'r' and/or 'theta' (0 filled in for missing elements)
	#		(2) a matrix of columns representing 'r' and/or 'theta' (0 filled in for missing columns)
	#		(3) a matrix of rows representing 'r' and/or 'theta' (0 filled in for missing columns), if which case perm needs to be TRUE
	#		(4) a list of elements names "r" and "theta"
	# ---theta--- is a vector of theta-values (optional).
	# ---perm--- is TRUE if the input points 'r' are given as a row matrix (see 'r').
	# ---list.out--- is TRUE if the output should be put in a list.
	
	
	##################################################
	##################################################
	##### Preparation, execution and output #####
	# List input for 'r':
	if(is.list(r)){
		names(r)=tolower(names(r))
		if(!is.null(r$r) && !is.null(r$theta)){
			out=cbind(x=c(r$r)*cos(c(r$theta)), y=c(r$r)*sin(c(r$theta)))
			}
		else{
			out=cbind(x=c(r[[1]])*cos(c(r[[2]])), y=c(r[[1]])*sin(c(r[[2]])))
			}
		}
	# Array input for 'r':
	else if(is.null(theta)){
		dimr=dim(r)
		if(length(dimr)==2){
			if(perm){
				if(dimr[1]<2){
					# Add zeros for the 'theta' values:
					r=rbind(r,0)
					}
				out=rbind(x=r[1,]*cos(r[2,]), y=r[1,]*sin(r[2,]))
				}
			else{
				if(dimr[2]<2){
					# Add zeros for the 'theta' values:
					r=cbind(r,0)
					}
				out=cbind(x=r[,1]*cos(r[,2]), y=r[,1]*sin(r[,2]))
				}
			}
		else if(is.null(dimr)){
			if(length(r)<2){
				# Add zeros for the 'theta' and/or 'phi' values:
				r=c(r,0)
				}
			out=c(x=r[1]*cos(r[2]), y=r[1]*sin(r[2]))
			}
		else{
			stop("Invalid input")
			}
		}
	# Individual inputs:
	else{
		out=cbind(x=r*cos(theta), y=r*sin(theta))
		}
	# If list output is required:
	if(list.out){
		list(x=out[,1],y=out[,2])
		}
	else{
		out
		}
	##################################################
	##################################################
	}
