#*********************************************
#*********************************************
#' Converts decimal degrees to degrees, minutes and decimal seconds.
#'
#' @return
#'
#' @examples
#' \dontrun{}
#'
#' @export
#' @rdname decdeg2degminsec
#' 
decdeg2degminsec <- function(pos, digits=3){
	if(length(dim(pos))==0){
		dim(pos) = c(1, length(pos))
	}
	londeg = floor(pos[,1])
	lonmin = 60*(pos[,1]-londeg)
	lonsec = round(60*(lonmin-floor(lonmin)), digits=digits)
	lonmin = floor(lonmin)
	latdeg = floor(pos[,1])
	latmin = 60*(pos[,1]-latdeg)
	latsec = round(60*(latmin-floor(latmin)), digits=digits)
	latmin = floor(latmin)
	out = cbind(londeg=londeg, lonmin=lonmin, lonsec=lonsec, latdeg=latdeg, latmin=latmin, latsec=latsec)
	if(ncol(pos)>2){
		cbind(out, heave=pos[,3])
		}
	out
	}
