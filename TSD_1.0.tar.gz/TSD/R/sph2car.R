#*********************************************
#*********************************************
#' Transformation from spherical (polar) coordinates given as 'r', 'theta' and 'phi' as in Zwillinger (1985, pp. 297-298) and on http://mathworld.wolfram.com/SphericalCoordinates.html, to cartesian coordinates.
#'
#' @param r  represents the points to transform, structured in one of the 4 following ways:
#' @param theta  is a vector of theta-values (optional).
#' @param phi  is a vector of phi-values (optional).
#' @param perm  is TRUE if the input points 'r' are given as a row matrix (see 'r').
#' @param list.out  is TRUE if the output should be put in a list.
#'
#' @return
#'
#' @examples
#' \dontrun{}
#'
#' @export
#' @rdname sph2car
#'
sph2car<-function(r,theta=NULL,phi=NULL,perm=FALSE,list.out=FALSE){
	
	############ AUTHOR(S): ############
	# Arne Johannes Holmin
	############ LANGUAGE: #############
	# English
	############### LOG: ###############
	# Start: 2008-03-11 - Finished.
	# Update:  2009-03-08 - Changed input to more robust.
	# Update:  2009-07-28 - Removed input variable 'drop.out'. Added support for list input and changed interpretation of 'r', 'rheta' and 'phi' so that if is.null(theta) or is.null(phi) and 'r' is a vector or a matrix of less than 3 columns, then theta=0 and/or phi=0.
	# Update:  2010-06-02 - Function altered to returning the output at each case of the input. Also added the option 'perm', allowing for row matrices. All in all reducing CPU time to 75 %.
	# Update:  2010-06-09 - One option added: 'list.out' (see VARIABLES). Also 'out' defined prior to all assignments of 'out'. CPU time reduction to 80 %.
	# Last:  2010-08-27 - Replaced data frame output by list output.
	########### DESCRIPTION: ###########
	# Transformation from spherical (polar) coordinates given as 'r', 'theta' and 'phi' as in Zwillinger (1985, pp. 297-298) and on http://mathworld.wolfram.com/SphericalCoordinates.html, to cartesian coordinates.
	########## DEPENDENCIES: ###########
	#
	############ VARIABLES: ############
	# ---r--- represents the points to transform, structured in one of the 4 following ways:
	#		(1) is either a vector of 'r' and/or 'theta' and/or 'phi' (0 filled in for missing elements)
	#		(2) a matrix of columns representing 'r' and/or 'theta' and/or 'phi' (0 filled in for missing columns)
	#		(3) a matrix of rows representing 'r' and/or 'theta' and/or 'phi' (0 filled in for missing columns), if which case perm needs to be TRUE
	#		(4) a list of elements names "r", "theta" and "phi"
	# ---theta--- is a vector of theta-values (optional).
	# ---phi--- is a vector of phi-values (optional).
	# ---perm--- is TRUE if the input points 'r' are given as a row matrix (see 'r').
	# ---list.out--- is TRUE if the output should be put in a list.
	
	
	##################################################
	##################################################
	##### Preparation, execution and output #####
	# List input for 'r':
	if(is.list(r)){
		names(r)=tolower(names(r))
		if(!is.null(r$r) && !is.null(r$theta) && !is.null(r$phi)){
			out=c(r$r)*sin(c(r$phi))
			out=cbind(x=out*cos(c(r$theta)), y=out*sin(c(r$theta)), z=c(r$r)*cos(c(r$phi)))
			}
		else{
			out=c(r[[1]])*sin(c(r[[3]]))
			out=cbind(x=out*cos(c(r[[2]])), y=out*sin(c(r[[2]])), z=c(r[[1]])*cos(c(r[[3]])))
			}
		}
	# Array input for 'r':
	else if(is.null(theta) || is.null(phi)){
		dimr=dim(r)
		if(length(dimr)==2){
			if(perm){
				if(dimr[1]<3){
					# Add zeros for the 'theta' and/or 'phi' values:
					rrest=double(dimr[2]*(3-dimr[1]))
					dim(rrest)=c(dimr[2],3-dimr[1])
					r=rbind(r,rrest)
					}
				out=r[1,]*sin(r[3,])
				out=rbind(x=out*cos(r[2,]), y=out*sin(r[2,]), z=r[1,]*cos(r[3,]))
				}
			else{
				if(dimr[2]<3){
					# Add zeros for the 'theta' and/or 'phi' values:
					rrest=double(dimr[1]*(3-dimr[2]))
					dim(rrest)=c(dimr[1],3-dimr[2])
					r=cbind(r,rrest)
					}
				out=r[,1]*sin(r[,3])
				out=cbind(x=out*cos(r[,2]), y=out*sin(r[,2]), z=r[,1]*cos(r[,3]))
				}
			}
		else if(is.null(dimr)){
			if(length(r)<3){
				# Add zeros for the 'theta' and/or 'phi' values:
				rrest=double(3-length(r))
				r=c(r,rrest)
				}
			out=r[1]*sin(r[3])
			out=c(x=out*cos(r[2]), y=out*sin(r[2]), z=r[1]*cos(r[3]))
			}
		else{
			stop("Invalid input")
			}
		}
	# Individual inputs:
	else{
		out=r*sin(phi)
		out=cbind(x=out*cos(theta), y=out*sin(theta), z=r*cos(phi))
		}
	# If list output is required:
	if(list.out){
		list(x=out[,1],y=out[,2],z=out[,3])
		}
	else{
		out
		}
	##################################################
	##################################################
	}
