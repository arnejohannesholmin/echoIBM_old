#*********************************************
#*********************************************
#' Transforms time given either as MATLAB serial date number 'mtim' (number of days since January 0, 0000), 'utim' (number of seconds elapsed since UTC 00:00, 1970-01-01), or 'ftim' (yyyyddHHMMSS.FFF or yyyymmddSSSSS.FFF) to MATLAB serial date number.
#'
#' @param x  is a vector of time points given as 'mtim' (number of days since January 0, 0000), 'utim' (number of seconds elapsed since UTC 00:00, 1970-01-01), 'ftim' (yyyyddHHMMSS.FFF or yyyymmddSSSSS.FFF).
#'
#' @return
#'
#' @examples
#' \dontrun{}
#'
#' @export
#' @rdname interpret.mtim
#'
interpret.mtim<-function(x){
	
	############ AUTHOR(S): ############
	# Arne Johannes Holmin
	############ LANGUAGE: #############
	# English
	############### LOG: ###############
	# Start: 2013-07-11 - Clean version.
	########### DESCRIPTION: ###########
	# Transforms time given either as MATLAB serial date number 'mtim' (number of days since January 0, 0000), 'utim' (number of seconds elapsed since UTC 00:00, 1970-01-01), or 'ftim' (yyyyddHHMMSS.FFF or yyyymmddSSSSS.FFF) to MATLAB serial date number.
	########## DEPENDENCIES: ###########
	#
	############ VARIABLES: ############
	# ---x--- is a vector of time points given as 'mtim' (number of days since January 0, 0000), 'utim' (number of seconds elapsed since UTC 00:00, 1970-01-01), 'ftim' (yyyyddHHMMSS.FFF or yyyymmddSSSSS.FFF).
	
	
	##################################################
	##################################################
	##### Preparation #####
	ncharx=nchar(x)
	m=ncharx<=6
	u=ncharx %in% c(9,10)
	f=ncharx %in% c(8,13,14)
	

	##### Execution #####
	mtim=NAs(length(x))
	mtim[m]=x[m]
	mtim[u]=utim2mtim(x[u])
	mtim[f]=ftim2mtim(x[f])
	
	
	##### Output #####
	mtim
	##################################################
	##################################################
	}
