#*********************************************
#*********************************************
#' Transforms time input in TSD format to UTC matlab time.
#'
#' @param data  is a list with names as used in the TSD file format (usually from read.TSD()).
#' @param keep.list  is TRUE if 'mtim' is to be returned as a list even though only one vector of 'mtim' is extracted.
#'
#' @return
#'
#' @examples
#' \dontrun{}
#'
#' @export
#' @rdname mtim.TSD
#'
mtim.TSD<-function(data,keep.list=FALSE,...){
	
	############ AUTHOR(S): ############
	# Arne Johannes Holmin
	############ LANGUAGE: #############
	# English
	############### LOG: ###############
	# Start: 2010-01-30 - Clean version.
	# Update: 2010-03-03 - Altered to fully utilize the functions ftim2mtim, ftim2utim, mtim2ftim, mtim2utim, utim2ftim and utim2mtim.
	# Update: 2010-07-13 - Added support for list input.
	# Update: 2010-10-19 - Added support for multiple elements of identical names in the input.
	# Last: 2015-04-28 - Removed support for 'ctim', which can now be used freely as time information that do not interfer with the time information stored in 'utim', 'mtim', and 'ftim'.
	########### DESCRIPTION: ###########
	# Transforms time input in TSD format to UTC matlab time.
	########## DEPENDENCIES: ###########
	# utim2mtim(), ftim2mtim()
	############ VARIABLES: ############
	# ---data--- is a list with names as used in the TSD file format (usually from read.TSD()).
	# ---keep.list--- is TRUE if 'mtim' is to be returned as a list even though only one vector of 'mtim' is extracted.
	
	
	##################################################
	##################################################
	if(!any(rm.na(names(data)=="mtim"))){
		if(any(rm.na(names(data)=="utim"))){
			utim=data[names(data)=="utim"]
			notEmpty=unlist(lapply(utim,length)>0)
			if(any(notEmpty)){
				utim=utim[notEmpty]
				}
			mtim=lapply(utim,function(x) if(is.list(x)) lapply(x,utim2mtim,...) else utim2mtim(x,...))
			if(length(mtim)==1 && !keep.list){
				mtim[[1]]
				}
			else{
				mtim
				}
			}
		else if(any(rm.na(names(data)=="ftim"))){
			ftim=data[names(data)=="ftim"]
			notEmpty=unlist(lapply(ftim,length)>0)
			if(any(notEmpty)){
				ftim=ftim[notEmpty]
				}
			mtim=lapply(ftim,function(x) if(is.list(x)) lapply(x,ftim2mtim,...) else ftim2mtim(x,...))
			if(length(mtim)==1 && !keep.list){
				mtim[[1]]
				}
			else{
				mtim
				}
			}
		}
	else{
		mtim=data[names(data)=="mtim"]
		notEmpty=unlist(lapply(mtim,length)>0)
		if(any(notEmpty)){
			mtim=mtim[notEmpty]
			}
		if(length(mtim)==1 && !keep.list){
			mtim[[1]]
			}
		else{
			mtim
			}
		}
	##################################################
	##################################################
	}
