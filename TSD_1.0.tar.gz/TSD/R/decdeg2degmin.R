#*********************************************
#*********************************************
#' Converts decimal degrees to degrees and decimal minutes.
#'
#' @return
#'
#' @examples
#' \dontrun{}
#'
#' @export
#' @rdname decdeg2degmin
#' 
decdeg2degmin <- function(pos, digits=3){
	if(length(dim(pos))==0){
		dim(pos) = c(1, length(pos))
	}
	londeg = floor(pos[,1])
	lonmin = round(60*(pos[,1]-londeg), digits=digits)
	latdeg = floor(pos[,2])
	latmin = round(60*(pos[,2]-latdeg), digits=digits)
	out = cbind(londeg=londeg, lonmin=lonmin, latdeg=latdeg, latmin=latmin)
	if(ncol(pos)>2){
		cbind(out, heave=pos[,3])
		}
	out
	}
