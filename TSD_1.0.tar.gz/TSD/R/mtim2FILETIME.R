#*********************************************
#*********************************************
#' Transforms MATLAB serial date (Number of days since Jesus was born) to Windows FILETIME (the number of 100 nanoseconds since 1 January 1601).
#'
#' @param x  are the time points given in MATLAB serial date number.
#' @param xBase  is the base of Windows FILETIME: xBase=unclass(as.POSIXct('1601-1-1', tz="UTC"))[1].
#' @param tz  is the the time zone. Overrides 'xBase' if not given as tz="UTC". See as.POSIXlt().
#'
#' @return
#'
#' @examples
#' \dontrun{}
#'
#' @export
#' @rdname mtim2FILETIME
#'
mtim2FILETIME<-function(x, xBase=-11644473600, tz="UTC"){
	
	############ AUTHOR(S): ############
	# Arne Johannes Holmin
	############ LANGUAGE: #############
	# English
	############### LOG: ###############
	# Start: 2013-10-23 - Clean version.
	########### DESCRIPTION: ###########
	# Transforms MATLAB serial date (Number of days since Jesus was born) to Windows FILETIME (the number of 100 nanoseconds since 1 January 1601).
	########## DEPENDENCIES: ###########
	#
	############ VARIABLES: ############
	# ---x--- are the time points given in MATLAB serial date number.
	# ---xBase--- is the base of Windows FILETIME: xBase=unclass(as.POSIXct('1601-1-1', tz="UTC"))[1].
	# ---tz--- is the the time zone. Overrides 'xBase' if not given as tz="UTC". See as.POSIXlt().
	
	
	##################################################
	##################################################
	##### Preparation #####
	if(!tz=="UTC"){
		xBase=unclass(as.POSIXct('1601-1-1', tz=tz))[1]
		}
	# The number of seconds in a day:
	nsec=86400
	# Matlab serial date at the start of UNIX/POSIX time:
	days1970=719529
	
	
	##### Execution and output #####
	# Convert from Windows FILETIME and return:
	( (x-days1970)*nsec - xBase) * 1e7
	##################################################
	##################################################
	}
