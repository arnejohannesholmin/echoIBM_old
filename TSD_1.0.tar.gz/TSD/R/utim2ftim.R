#*********************************************
#*********************************************
#' Transforms unix time to formatted time D=yyyymmdd and T=HHMMSS.FFF in a column matrix or vector.
#'
#' @param x  are the input time points in unix time.
#' @param format  is a string specifying the format of the return values. "yyyy" denotes year, "mm" denotes month, "dd" denotes day, "HH" denotes hour, "MM" denotes minutes, "SS" denotes seconds and "FFF" denotes fractional seconds of 'digits' digits. (Similar to the MATLAB function timestr()). Also an index number given by 'indt' can be added in the output, as well as text and separators, such as "yyyy-mm-dd\\nHH:MM:SS.FFF\\nPing: indt", which separates the date, time, and ping number in acoustic data by line spaces.
#' @param digits  is the number of digits to return after seconds.
#' @param indt  is the optional index number to add to the output.
#' @param split  is TRUE if the formated time points are to be returned as a matrix of columns "D" and "T".
#' @param numeric  is TRUE if the time values are to be returned as a numeric column matrix (only in the case split==TRUE).
#' @param ...  added to avoid the error "unused argument" in ftim.TSD().
#'
#' @return
#'
#' @examples
#' \dontrun{}
#'
#' @export
#' @rdname utim2ftim
#'
utim2ftim<-function(x, format="yyyymmddHHMMSS.FFF", digits=3, indt=NULL, split=FALSE, numeric=FALSE, ...){
	
	############ AUTHOR(S): ############
	# Arne Johannes Holmin
	############ LANGUAGE: #############
	# English
	############### LOG: ###############
	# Start: 2010-01-30 - Clean version.
	# Update: 2010-11-11 - Changed to resemble the function datestr() in MATLAB, taking an arbitrary format argument 'format', including key strings:
	# Last: 2014-05-27 - Added 'indt'.
	########### DESCRIPTION: ###########
	# Transforms unix time to formatted time D=yyyymmdd and T=HHMMSS.FFF in a column matrix or vector.
	########## DEPENDENCIES: ###########
	#
	############ VARIABLES: ############
	# ---x--- are the input time points in unix time.
	# ---format--- is a string specifying the format of the return values. "yyyy" denotes year, "mm" denotes month, "dd" denotes day, "HH" denotes hour, "MM" denotes minutes, "SS" denotes seconds and "FFF" denotes fractional seconds of 'digits' digits. (Similar to the MATLAB function timestr()). Also an index number given by 'indt' can be added in the output, as well as text and separators, such as "yyyy-mm-dd\nHH:MM:SS.FFF\nPing: indt", which separates the date, time, and ping number in acoustic data by line spaces.
	# ---digits--- is the number of digits to return after seconds.
	# ---indt--- is the optional index number to add to the output.
	# ---split--- is TRUE if the formated time points are to be returned as a matrix of columns "D" and "T".
	# ---numeric--- is TRUE if the time values are to be returned as a numeric column matrix (only in the case split==TRUE).
	# ---...--- added to avoid the error "unused argument" in ftim.TSD().
	
	
	##################################################
	##################################################
	##### Preparation #####
	if(length(x)==0){
		return(NULL)
		}
	x = round(x, digits=digits)
	
	
	##### Execution #####
	# Get values:
	FFF = substr(x-floor(x), 3, 3-1+digits)
	# Transform time:
	x = as.character(as.POSIXct(x, "GMT", origin="1970-01-01 00:00:00 GMT"))
	yyyy = substr(x, 1, 4)
	mm = substr(x, 6, 7)
	dd = substr(x, 9, 10)
	HH = substr(x, 12, 13)
	MM = substr(x, 15, 16)
	SS = substr(x, 18, 19)
	allvalues = cbind(yyyy, mm, dd, HH, MM, SS, FFF, if(length(indt)==0) "" else indt)
	
	# Locate key strings:
	atyyyy = gregexpr("yyyy", format)[[1]]
	atmm = gregexpr("mm", format)[[1]]
	atdd = gregexpr("dd", format)[[1]]
	atHH = gregexpr("HH", format)[[1]]
	atMM = gregexpr("MM", format)[[1]]
	atSS = gregexpr("SS", format)[[1]]
	atFFF = gregexpr("FFF", format)[[1]]
	atindt = gregexpr("indt", format)[[1]]
	# 'allat' is a matrix of 3 columns where the first holds the positions of key strings, the second is the corresponding identification values (1: yyyy, 2: mm, 3: dd, 4: HH, 5: MM, 6: SS, 7: FFF, 8: indt) and the third is the lengths of the key strings:
	allat = cbind(unlist(c(atyyyy, atmm, atdd, atHH, atMM, atSS, atFFF, atindt)), rep(1:8, c(length(atyyyy), length(atmm), length(atdd), length(atHH), length(atMM), length(atSS), length(atFFF), length(atindt))))
	allat = cbind(allat, c(4,2,2,2,2,2,3,4)[allat[,2]])
	# Strip 'allat' of missing key strings:
	validat = which(allat[,1]!=-1)
	allat = allat[validat,]
	# Order 'allat' according to apparence in 'format':
	allat = allat[order(allat[,1]),]
	
	# Get separators:
	sepall = NULL
	for(i in seq_len(nrow(allat)-1)){
		sepall = c(sepall, substr(format, allat[i,1]+allat[i,3], allat[i+1,1]-1))
		}
	
	
	##### Output #####
	start = substr(format, 1, allat[1,1]-1)
	end = substring(format, allat[nrow(allat),1]+allat[nrow(allat),3])
	out = paste0(start, allvalues[,allat[1,2]])
	if(split){
		# Return column matrix of the date and time values:
		for(i in seq_along(sepall)){
			out = cbind(out, allvalues[,allat[i+1,2]])
			}
		if(numeric){
			dimout = dim(out)
			out = array(as.numeric(out), dim=dimout)
			}
		}
	else{
		# Return strings of the date and time values:
		for(i in seq_along(sepall)){
			thisval = allvalues[,allat[i+1,2]]
			thissep = rep(sepall[i], length(thisval))
			thissep[nchar(thisval)==0] = ""
			out = paste0(out, thissep, thisval)
			}
		}
	paste0(out, end)
	##################################################
	##################################################
	}
