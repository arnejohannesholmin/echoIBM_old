#*********************************************
#*********************************************
#' Transforms UNIX time to Windows FILETIME (the number of 100 nanoseconds since 1 January 1601).
#'
#' @param x  are the time points given in UNIX time (the number of seconds since 1 January 1970).
#' @param xBase  is the base of Windows FILETIME: xBase=unclass(as.POSIXct('1601-1-1', tz="UTC"))[1].
#' @param tz  is the the time zone. Overrides 'xBase' if not given as tz="UTC". See as.POSIXlt().
#'
#' @return
#'
#' @examples
#' \dontrun{}
#'
#' @export
#' @rdname utim2FILETIME
#'
utim2FILETIME<-function(x, xBase=-11644473600, tz="UTC"){
	
	############ AUTHOR(S): ############
	# Arne Johannes Holmin
	############ LANGUAGE: #############
	# English
	############### LOG: ###############
	# Start: 2013-10-23 - Clean version.
	########### DESCRIPTION: ###########
	# Transforms UNIX time to Windows FILETIME (the number of 100 nanoseconds since 1 January 1601).
	########## DEPENDENCIES: ###########
	#
	############ VARIABLES: ############
	# ---x--- are the time points given in UNIX time (the number of seconds since 1 January 1970).
	# ---xBase--- is the base of Windows FILETIME: xBase=unclass(as.POSIXct('1601-1-1', tz="UTC"))[1].
	# ---tz--- is the the time zone. Overrides 'xBase' if not given as tz="UTC". See as.POSIXlt().
	
	
	##################################################
	##################################################
	if(!tz=="UTC"){
		xBase=unclass(as.POSIXct('1601-1-1', tz=tz))[1]
		}
	# Convert from seconds to Windows FILETIME and return:
	(x-xBase)*1e7
	##################################################
	##################################################
	}
