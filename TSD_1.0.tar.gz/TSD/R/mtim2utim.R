#*********************************************
#*********************************************
#' Transforms matlab time in UTC to unix time.
#'
#' @param x  are the input time points in UTC matlab time.
#' @param ...  added to avoid the error "unused argument" in utim.TSD().
#'
#' @return
#'
#' @examples
#' \dontrun{}
#'
#' @export
#' @rdname mtim2utim
#'
mtim2utim<-function(x,...){
	
	############ AUTHOR(S): ############
	# Arne Johannes Holmin
	############ LANGUAGE: #############
	# English
	############### LOG: ###############
	# Start: 2010-03-03 - Clean version.
	########### DESCRIPTION: ###########
	# Transforms matlab time in UTC to unix time.
	########## DEPENDENCIES: ###########
	#
	############ VARIABLES: ############
	# ---x--- are the input time points in UTC matlab time.
	# ---...--- added to avoid the error "unused argument" in utim.TSD().
	
	
	##################################################
	##################################################
	##### Preparation #####
	days1970=719529
	# The number of seconds in a day:
	nsec=86400
	
	
	##### Execution #####
	(x-days1970)*nsec
	##################################################
	##################################################
	}
