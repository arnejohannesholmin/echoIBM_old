#*********************************************
#*********************************************
#' Returning TRUE at all even values.
#'
#' @param x  is the R-object to be checked for even values.
#'
#' @return
#'
#' @examples
#' \dontrun{}
#'
#' @export
#' @rdname even
#'
even<-function(x){
	
	############ AUTHOR(S): ############
	# Arne Johannes Holmin
	############ LANGUAGE: #############
	# English
	############### LOG: ###############
	# Start: 2008-11-14 - Done.
	########### DESCRIPTION: ###########
	# Returning TRUE at all even values.
	########## DEPENDENCIES: ###########
	#
	############ VARIABLES: ############
	# ---x--- is the R-object to be checked for even values.
	
	
	##################################################
	##################################################
	!as.logical(x%%2)
	##################################################
	##################################################
	}
