#*********************************************
#*********************************************
#'
#' @export
#' @rdname zeros
#' 
chars<-function(...){
	# Start: 2008-08-31 - Bad version.
	# Update: 2009-02-17 - Finished.
	# Update: 2009-02-23 - Use of double() to speed the function up to half the time as array().
	# Update: 2009-02-03 - Support for list objects in input.
	# Last: 2009-04-06 - Inherited from zeros.
	##### Preparation #####
	dimension=unlist(list(...))
	if(is.null(dimension)){
		dimension=0
		}
	l=prod(dimension)
	if(length(dimension)==1){
		dimension=NULL
		}
	
	##### Execution and output #####
	out=character(l)
	dim(out)=dimension
	out
	}
