#*********************************************
#*********************************************
#' Transformation from cartesian to spherical (polar) coordinates returned as 'r', 'theta' and 'phi' as in Zwillinger (1985, pp. 297-298) and on http://mathworld.wolfram.com/SphericalCoordinates.html.
#'
#' @param x  represents the points to transform, structured in one of the 4 following ways:
#' @param y  is a vector of y-values (optional).
#' @param perm  is TRUE if the input points 'r' are given as a row matrix (see 'r').
#' @param nonneg  is TRUE if negative values of 'theta' should be added 2*pi.
#' @param list.out  is TRUE if the output should be put in a list.
#'
#' @return
#'
#' @examples
#' \dontrun{}
#'
#' @export
#' @rdname car2pol
#'
car2pol<-function(x,y=NULL,perm=FALSE,nonneg=FALSE,list.out=FALSE){
	
	############ AUTHOR(S): ############
	# Arne Johannes Holmin
	############ LANGUAGE: #############
	# English
	############### LOG: ###############
	# Start: 2008-03-11 - Finished.
	# Update:  2009-03-08 - Changed input to more robust.
	# Update:  2009-07-28 - Removed input variable 'drop.out'. Added support for list input and changed interpretation of 'x' and 'y' so that if is.null(y) and 'x' is a vector or a single column matrix, then y=0.
	# Update:  2010-06-02 - Function altered to returning the output at each case of the input. Also added the option 'perm', allowing for row matrices. All in all reducing CPU time to 85 %.
	# Update:  2010-06-09 - Two options added: 'nonneg' and 'list.out' (see VARIABLES). CPU time reduction to 85 %.
	# Last:  2010-08-27 - Replaced data frame output by list output.
	########### DESCRIPTION: ###########
	# Transformation from cartesian to spherical (polar) coordinates returned as 'r', 'theta' and 'phi' as in Zwillinger (1985, pp. 297-298) and on http://mathworld.wolfram.com/SphericalCoordinates.html.
	########## DEPENDENCIES: ###########
	#
	############ VARIABLES: ############
	# ---x--- represents the points to transform, structured in one of the 4 following ways:
	#		(1) is either a vector of 'x' and/or 'y' (0 filled in for missing elements)
	#		(2) a matrix of columns representing 'x' and/or 'y' (0 filled in for missing columns)
	#		(3) a matrix of rows representing 'x' and/or 'y' (0 filled in for missing columns), if which case perm needs to be TRUE
	#		(4) a list of elements names "x" and "y"
	# ---y--- is a vector of y-values (optional).
	# ---perm--- is TRUE if the input points 'r' are given as a row matrix (see 'r').
	# ---nonneg--- is TRUE if negative values of 'theta' should be added 2*pi.
	# ---list.out--- is TRUE if the output should be put in a list.
	
	
	##################################################
	##################################################
	##### Preparation, execution and output #####
	# List input for 'x':
	if(is.list(x)){
		names(x)=tolower(names(x))
		if(!is.null(x$x) && !is.null(x$y)){
			out=cbind(r=c(sqrt(x$x^2+x$y^2)), theta=c(atan2(x$y,x$x)))
			}
		else{
			out=cbind(r=c(sqrt(x[[1]]^2+x[[2]]^2)), theta=c(atan2(x[[2]],x[[1]])))
			}
		}
	# Array input for 'x':
	else if(is.null(y)){
		dimx=dim(x)
		if(length(dimx)==2){
			if(perm){
				if(dimx[1]<2){
					# Add zeros for the 'y' values:
					x=rbind(x,0)
					}
				out=rbind(r=sqrt(x[1,]^2+x[2,]^2), theta=atan2(x[2,],x[1,]))
				}
			else{
				if(dimx[2]<2){
					# Add zeros for the 'y' values:
					x=cbind(x,0)
					}
				out=cbind(r=c(sqrt(x[,1]^2+x[,2]^2)), theta=c(atan2(x[,2],x[,1])))
				}
			}
		else if(is.null(dimx)){
			if(length(x)<2){
				# Add zeros for the 'y' values:
				x=c(x,0)
				}
			out=c(r=sqrt(x[1]^2+x[2]^2), theta=atan2(x[2],x[1]))
			}
		else{
			stop("Invalid input")
			}
		}
	# Individual inputs:
	else{
		out=cbind(r=c(sqrt(x^2+y^2)), theta=c(atan2(y,x)))
		}
	# If non-negative 'theta' (azimuth angle) is required:
	if(nonneg){
		out[,2]=out[,2]%%(2*pi)
		}
	# If list output is required:
	if(list.out){
		list(r=out[,1],theta=out[,2])
		}
	else{
		out
		}
	##################################################
	##################################################
	}
