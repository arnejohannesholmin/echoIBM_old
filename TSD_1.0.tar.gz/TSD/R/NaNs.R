#*********************************************
#*********************************************
#'
#' @export
#' @rdname zeros
#' 
NaNs<-function(...){
	# Start: 2008-08-31 - Bad version.
	# Update: 2009-02-17 - Finished.
	# Last: 2009-02-03 - Support for list objects in input.
	
	##### Preparation #####
	dimension=unlist(list(...))
	if(is.null(dimension)){
		dimension=0
		}
	l=prod(dimension)
	if(length(dimension)==1){
		dimension=NULL
		}
	
	##### Execution and output #####
	out=rep(NaN,l)
	dim(out)=dimension
	out
	}
