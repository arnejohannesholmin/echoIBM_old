#*********************************************
#*********************************************
#' Transforms 'ftim' in the TSD file format to a list used by ftim2mtim() and ftim2utim().
#'
#' @param x  are the input time points given as 'ftim' in the TSD file format.
#' @param ...  added to avoid the error "unused argument" in mtim.TSD().
#'
#' @return
#'
#' @examples
#' \dontrun{}
#'
#' @export
#' @rdname ftim2list
#'
ftim2list<-function(x, ...){
	
	############ AUTHOR(S): ############
	# Arne Johannes Holmin
	############ LANGUAGE: #############
	# English
	############### LOG: ###############
	# Start: 2010-01-30 - Clean version.
	########### DESCRIPTION: ###########
	# Transforms 'ftim' in the TSD file format to a list used by ftim2mtim() and ftim2utim().
	########## DEPENDENCIES: ###########
	#
	############ VARIABLES: ############
	# ---x--- are the input time points given as 'ftim' in the TSD file format.
	# ---...--- added to avoid the error "unused argument" in mtim.TSD().
	
	
	##################################################
	##################################################
	##### Preparation #####
	if(length(x)==0){
		return(NULL)
		}
	# Accept string specifications of the ftim:
	x = format(x, scientific=FALSE)
	x = gsub("[[:punct:]]", "", x)
	x = gsub("[[:space:]]", "", x)
	# Add 000000 at the end, and 20 at the beginning and 000000 at the end if the number of digits is 8 or 6, respectively:
	if(nchar(x[1])==6 && is.numeric(x[1])){
		last=as.numeric(substr(x,1,2))>as.numeric(substr(format(Sys.time(), "%Y"),3,4))
		x=paste0(c("20","19")[last+1],x,"000000")
		}
	else if(nchar(x[1])==8){
		x=paste0(x,"000000")
		}
	ncharx = nchar(x)
	FFF = double(length(x))
	if(any(ncharx>14)){
		larger = ncharx>14
		suppressWarnings(FFF[larger]<-as.numeric(paste0(".",substring(x[larger], 15))))
		suppressWarnings(x<-as.numeric(x))
		x[larger] = x[larger]/10^(ncharx[larger]-14)
		}
	else{
		suppressWarnings(x<-as.numeric(x))
		}
	# 'add' is a logical that is true if the time format is yyyymmddHHMMSS.FFF and false in the case yyyymmddSSSSS.FFF:
	add=x>1e13
	add[is.na(add)]=FALSE
	
	
	##### Execution #####
	# The calculation of 'y', 'm' and 'd':
	c=10^(9+add)
	y=floor(x/c)
	x=x-y*c
	c=10^(7+add)
	m=floor(x/c)
	x=x-m*c
	c=10^(5+add)
	d=floor(x/c)
	# If add==FALSE 'S' is the correct value for the seconds alpsed the given day. If add==TRUE some more calculations must be done:
	S=x-d*c
	if(any(add)){
		c=10^(3+add)
		H=floor(S/c)
		S=S-H*c
		c=10^(1+add)
		M=floor(S/c)
		S=S-M*c + H*3600 + M*60
		}
	# Add the digits of the seconds:
	S = floor(S) + FFF 
	# 'ally' is a year sequence used in the treatment of leap years:
	ally=0:max(y,na.rm=TRUE)
	# 'ly' is a locigal vector giving the leap years, and 'cly' are the number of leap years from year 0:
	ly=ally%%4 == 0 & (ally%%100 != 0 | ally%%400 == 0)
	cly=cumsum(ly)
	# 'cd' are the number of days elapsed through the months the given year:
	cd=c(0,31,59,90,120,151,181,212,243,273,304,334)
	# Subtract 1 from 'd' since the given day does not count:
	d=d+cd[m]-1
	
	
	##### Output #####
	list(y=y, cly=cly, d=d, ly=ly, m=m, S=S)
	##################################################
	##################################################
	}
