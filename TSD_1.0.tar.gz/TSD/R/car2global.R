#*********************************************
#*********************************************
#' Transforms points in a local coordinate system to the global coordinate system of Earth, given an origin in longitude, latitude and heave decimal values (DD). The output is in the range [-180,180] for longitude (East) and [-90,90] for latitude (North). Circular surface of the Earth is assumed in a neighbourhood around the 'origin'.
#'
#' @param pos  is a list, matrix or vector of the points to be transformed.
#' @param origin  is a vector of length 3 holding the origin of the cartesian coordinate system, given in longitude-latitude-heave decimal values (DD)).
#' @param list.out  is TRUE if the output should be put in a list.
#'
#' @return
#'
#' @examples
#' \dontrun{}
#'
#' @export
#' @rdname car2global
#'
car2global<-function(pos, origin=c(0,0,0), list.out=FALSE, format=c("dec", "min", "sec")){
	
	############ AUTHOR(S): ############
	# Arne Johannes Holmin
	############ LANGUAGE: #############
	# English
	############### LOG: ###############
	# Start: 2010-02-14 - Clean version.
	# Last: 2010-06-09 - Removed data.frame output reducing CPU time to 40 %.
	########### DESCRIPTION: ###########
	# Transforms points in a local coordinate system to the global coordinate system of Earth, given an origin in longitude, latitude and heave decimal values (DD). The output is in the range [-180,180] for longitude (East) and [-90,90] for latitude (North). Circular surface of the Earth is assumed in a neighbourhood around the 'origin'.
	########## DEPENDENCIES: ###########
	# zeros(), radiusEarth()
	############ VARIABLES: ############
	# ---pos--- is a list, matrix or vector of the points to be transformed.
	# ---origin--- is a vector of length 3 holding the origin of the cartesian coordinate system, given in longitude-latitude-heave decimal values (DD)).
	# ---list.out--- is TRUE if the output should be put in a list.
	
	
	##################################################
	##################################################
	##### Preparation #####
	# Support for list, matrix and vector input for 'pos':
	# List:
	if(is.list(pos)){
		namespos=names(pos)=tolower(names(pos))
		# 'origin' given in the list:
		if(!any(is.null(pos$lon0),is.null(pos$lat0))){
			origin=c(pos$lon0[1],pos$lat0[1],0)
			}
		
		hitspsx=grep("psx",namespos)
		hitspsy=grep("psy",namespos)
		hitspsz=grep("psz",namespos)
		# If non-unique names are present in the list:
		if(any(length(hitspsx)>1,length(hitspsy)>1,length(hitspsz)>1)){
			warning(paste("More than one set of 'psx*', 'psy*' and 'psz*' values. Selecting '",namespos[hitspsx[1]],"', '",namespos[hitspsy[1]],"' and '",namespos[hitspsz[1]],"'",sep=""))
			}
		
		if(any(length(hitspsx)>0,length(hitspsy)>0,length(hitspsz)>0)){
			if(length(hitspsx)==0){
				posx=0
				}
			else{
				posx=pos[[namespos[hitspsx[1]]]]
				}
			if(length(hitspsy)==0){
				posy=0
				}
			else{
				posy=pos[[namespos[hitspsy[1]]]]
				}
			if(length(hitspsz)==0){
				posz=0
				}
			else{
				posz=pos[[namespos[hitspsz[1]]]]
				}
			pos=cbind(posx,posy,posz)
			}
		else if(any(!is.null(pos$x),!is.null(pos$y),!is.null(pos$z))){
			if(is.null(pos$x)){
				pos$x=0
				}
			if(is.null(pos$y)){
				pos$y=0
				}
			if(is.null(pos$z)){
				pos$z=0
				}
			pos=cbind(pos$x,pos$y,pos$z)
			}
		# If names for longitude, latitude and heave (optional) are not given, [[1]] is interpreted as 'longitude', [[2]] is interpreted as 'latitude' and [[3]] is if present interpreted as 'heave'.
		else if(length(pos)>2){
			warning("First three list elements used as 'x', 'y' and 'z'")
			pos=cbind(pos[[1]],pos[[2]],pos[[3]])
			}
		else if(length(pos)>1){
			warning("First two list elements used as 'x' and 'y'")
			pos=cbind(pos[[1]],pos[[2]],0)
			}
		else if(length(pos)>0){
			warning("First list element used as 'x'")
			pos=cbind(pos[[1]],0)
			}
		else{
			warning("No postitions given")
			return(NULL)
			}
		}
	dimpos=dim(pos)
	# Matrix:
	if(length(dimpos)==2 && ncol(pos)<3){
		pos=cbind(pos,zeros(nrow(pos),3-ncol(pos)))
		}
	# Vector:
	else if(is.null(dimpos) && length(pos) %in% 1:3){
		pos=t(c(pos,double(3-length(pos))))
		}
	else if(length(dimpos)!=2){
		return(NULL)
		}
	# 'origin' must be a vector of length 3, or an integer specifying which global position to regard as the origin:
	lorigin=length(origin)
	# If origin is an integer in the range [1,nrow(pos)], the point pos[origin] is regarded as the 'origin':
	origin=as.numeric(origin)
	if(lorigin==2){
		origin=c(origin,0)
		}
	else if(lorigin<2){
		stop("'origin' of the global coordinate system must be given as a vector of 2 or more elements")
		}
	
	
	##### Execution and output #####
	# The positions from the origin divided by the radius of Earth at the latitude of origin:
	pos[,1] = origin[1] + pos[,1]/radiusEarth(origin[2],toaxis=TRUE)/pi*180
	pos[,2] = origin[2] + pos[,2]/radiusEarth(origin[2])/pi*180
	pos[,3] = pos[,3] + origin[3]
	colnames(pos) = c("lon","lat","heave")
	
	if("min"==format[1]){
		pos = decdeg2degmin(pos)
		}
	else if("sec"==format[1]){
		pos = decdeg2degminsec(pos)
		}
	
	# If list output is required:
	if(list.out){
		list(x=out[,1],y=out[,2],z=out[,3])
		}
	else{
		pos
		}
	##################################################
	##################################################
	}
