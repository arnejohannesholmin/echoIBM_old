#*********************************************
#*********************************************
#'
#' @export
#' @rdname zeros
#' 
ones<-function(...,type="double"){
	# Start: 2008-08-31 - Bad version.
	# Update: 2009-02-17 - Finished.
	# Update: 2009-02-23 - Use of double() to speed the function up to half the time as array().
	# Update: 2009-02-03 - Support for list objects in input.
	# Last: 2009-07-06 - Support for NULL input and 'type'. Method changed to using dim() on output, instead of using the array() function, reducing system time to 50%.

	##### Preparation #####
	dimension=unlist(list(...))
	if(is.null(dimension)){
		dimension=0
		}
	l=prod(dimension)
	if(length(dimension)==1){
		dimension=NULL
		}
	
	##### Execution and output #####
	if(type=="int"){
		output=integer(l)+as.integer(1)
		}
	else{
		output=double(l)+1
		}
	dim(output)=dimension
	output
	}
