#*********************************************
#*********************************************
#' @export
#' @rdname zeros
#' 
FALSEs<-function(...){
	# Start: 2009-03-08 - Finished.
	##### Preparation #####
	dimension=unlist(list(...))
	if(is.null(dimension)){
		dimension=0
		}
	l=prod(dimension)
	if(length(dimension)==1){
		dimension=NULL
		}
	
	##### Execution and output #####
	array(logical(l),dim=dimension)
	}
