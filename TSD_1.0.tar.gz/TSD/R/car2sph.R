#*********************************************
#*********************************************
#' Transformation from cartesian to spherical (polar) coordinates returned as 'r', 'theta' and 'phi' as in Zwillinger (1985, pp. 297-298) and on http://mathworld.wolfram.com/SphericalCoordinates.html.
#'
#' @param x  represents the points to transform, structured in one of the 4 following ways:
#' @param y  is a vector of y-values (optional).
#' @param z  is a vector of z-values (optional).
#' @param perm  is TRUE if the input points 'r' are given as a row matrix (see 'r').
#' @param nonneg  is TRUE if negative values of 'theta' should be added 2*pi.
#' @param list.out  is TRUE if the output should be put in a list.
#'
#' @return
#'
#' @examples
#' \dontrun{}
#'
#' @export
#' @rdname car2sph
#'
car2sph<-function(x,y=NULL,z=NULL,perm=FALSE,nonneg=FALSE,list.out=FALSE){
	
	############ AUTHOR(S): ############
	# Arne Johannes Holmin
	############ LANGUAGE: #############
	# English
	############### LOG: ###############
	# Start: 2008-03-11 - Finished.
	# Update:  2009-03-08 - Changed input to more robust.
	# Update:  2009-07-28 - Removed input variable 'drop.out'. Added support for list input and changed interpretation of 'x', 'y' and 'z' so that if is.null(y) or is.null(z) and 'x' is a vector or a matrix of less than 3 columns, then y=0 and/or z=0.
	# Update:  2010-06-02 - Function altered to returning the output at each case of the input. Also added the option 'perm', allowing for row matrices. All in all reducing CPU time to 90 %.
	# Update:  2010-06-09 - Two options added: 'nonneg' and 'list.out' (see VARIABLES). Also 'r' defined prior to all assignments of 'out'. CPU time reduction to 65 %.
	# Last:  2010-08-27 - Replaced data frame output by list output.
	########### DESCRIPTION: ###########
	# Transformation from cartesian to spherical (polar) coordinates returned as 'r', 'theta' and 'phi' as in Zwillinger (1985, pp. 297-298) and on http://mathworld.wolfram.com/SphericalCoordinates.html.
	########## DEPENDENCIES: ###########
	#
	############ VARIABLES: ############
	# ---x--- represents the points to transform, structured in one of the 4 following ways:
	#		(1) is either a vector of 'x' and/or 'y' and/or 'z' (0 filled in for missing elements)
	#		(2) a matrix of columns representing 'x' and/or 'y' and/or 'z' (0 filled in for missing columns)
	#		(3) a matrix of rows representing 'x' and/or 'y' and/or 'z' (0 filled in for missing columns), if which case perm needs to be TRUE
	#		(4) a list of elements names "x", "y" and "z"
	# ---y--- is a vector of y-values (optional).
	# ---z--- is a vector of z-values (optional).
	# ---perm--- is TRUE if the input points 'r' are given as a row matrix (see 'r').
	# ---nonneg--- is TRUE if negative values of 'theta' should be added 2*pi.
	# ---list.out--- is TRUE if the output should be put in a list.
	
	
	##################################################
	##################################################
	##### Preparation, execution and output #####
	# Function to ensure non-NA values for the point (0,0,0):
	acos_noNA=function(y,x){
		out=acos(y/x)
		out[x==0]=0
		out
		}
	
	# List input for 'x':
	if(is.list(x)){
		names(x)=tolower(names(x))
		if(!is.null(x$x) && !is.null(x$y) && !is.null(x$z)){
			out=sqrt(x$x^2+x$y^2+x$z^2)
			out=cbind(r=c(out), theta=c(atan2(x$y,x$x)), phi=c(acos_noNA(x$z,out)))
			}
		else{
			out=sqrt(x[[1]]^2+x[[2]]^2+x[[3]]^2)
			out=cbind(r=c(out), theta=c(atan2(x[[2]],x[[1]])), phi=c(acos_noNA(x[[3]],out)))
			}
		}
	# Array input for 'x':
	else if(is.null(y) || is.null(z)){
		dimx=dim(x)
		if(length(dimx)==2){
			if(perm){
				if(dimx[1]<3){
					# Add zeros for the 'y' and/or 'z' values:
					xrest=double(dimx[2]*(3-dimx[1]))
					dim(xrest)=c(dimx[2],3-dimx[1])
					x=rbind(x,xrest)
					}
				out=sqrt(x[1,]^2+x[2,]^2+x[3,]^2)
				out=rbind(r=out, theta=atan2(x[2,],x[1,]), phi=acos_noNA(x[3,],out))
				}
			else{
				if(dimx[2]<3){
					# Add zeros for the 'y' and/or 'z' values:
					xrest=double(dimx[1]*(3-dimx[2]))
					dim(xrest)=c(dimx[1],3-dimx[2])
					x=cbind(x,xrest)
					}
				out=sqrt(x[,1]^2+x[,2]^2+x[,3]^2)
				out=cbind(r=c(out), theta=c(atan2(x[,2],x[,1])), phi=c(acos_noNA(x[,3],out)))
				}
			}
		else if(is.null(dimx)){
			if(length(x)<3){
				# Add zeros for the 'y' and/or 'z' values:
				xrest=double(3-length(x))
				x=c(x,xrest)
				}
			out=sqrt(x[1]^2+x[2]^2+x[3]^2)
			out=c(r=out, theta=atan2(x[2],x[1]), phi=c(acos_noNA(x[3],out)))
			}
		else{
			stop("Invalid input")
			}
		}
	# Individual inputs:
	else{
		out=sqrt(x^2+y^2+z^2)
		out=cbind(r=c(out), theta=c(atan2(y,x)), phi=c(acos_noNA(z,out)))
		}
	# If non-negative 'theta' (azimuth angle) is required:
	if(nonneg){
		out[,2]=out[,2]%%(2*pi)
		}
	# If list output is required:
	if(list.out){
		list(r=out[,1],theta=out[,2],phi=out[,3])
		}
	else{
		out
		}
	##################################################
	##################################################
	}
