#*********************************************
#*********************************************
#' Transforms unix time to matlab time, which will be in UTC.
#'
#' @param utim  are the unix time points.
#' @param ...  added to avoid the error "unused argument" in mtim.TSD().
#'
#' @return
#'
#' @examples
#' \dontrun{}
#'
#' @export
#' @rdname utim2mtim
#'
utim2mtim<-function(utim, ...){
	
	############ AUTHOR(S): ############
	# Arne Johannes Holmin
	############ LANGUAGE: #############
	# English
	############### LOG: ###############
	# Start: 2010-02-15 - Clean version.
	########### DESCRIPTION: ###########
	# Transforms unix time to matlab time, which will be in UTC.
	########## DEPENDENCIES: ###########
	#
	############ VARIABLES: ############
	# ---utim--- are the unix time points.
	# ---...--- added to avoid the error "unused argument" in mtim.TSD().
	
	
	##################################################
	##################################################
	##### Preparation #####
	# Matlab serial date at the start of UNIX/POSIX time:
	days1970=719529
	# The number of seconds in a day:
	nsec=86400
	
	
	##### Execution and output #####
	utim/nsec+days1970
	##################################################
	##################################################
	}
