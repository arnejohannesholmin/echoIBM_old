#*********************************************
#*********************************************
#' Transforms 'ftim' in the TSD file format to unix time.
#'
#' @param x  are the input time points given as 'ftim' in the TSD file format.
#' @param ...  added to avoid the error "unused argument" in utim.TSD().
#'
#' @return
#'
#' @examples
#' \dontrun{}
#'
#' @export
#' @rdname ftim2utim
#'
ftim2utim<-function(x,...){
	
	############ AUTHOR(S): ############
	# Arne Johannes Holmin
	############ LANGUAGE: #############
	# English
	############### LOG: ###############
	# Start: 2010-01-30 - Clean version.
	########### DESCRIPTION: ###########
	# Transforms 'ftim' in the TSD file format to unix time.
	########## DEPENDENCIES: ###########
	#
	############ VARIABLES: ############
	# ---x--- are the input time points given as 'ftim' in the TSD file format.
	# ---...--- added to avoid the error "unused argument" in utim.TSD().
	
	
	##################################################
	##################################################
	##### Preparation #####
	temp = ftim2list(x,...)
	
	
	##### Execution and output #####
	(temp$y-1970)*31536000 + (temp$cly[temp$y] + temp$d + temp$ly[temp$y+1]*(temp$m>2) - temp$cly[1970])*86400 + temp$S
	##################################################
	##################################################
	}
