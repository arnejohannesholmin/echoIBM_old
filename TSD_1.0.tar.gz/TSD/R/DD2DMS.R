#*********************************************
#*********************************************
#' Simple function converting from decimal degrees to degrees, minutes and seconds:
#'
#' @param lon  is the vector of longitude values.
#' @param lat  is the vector of latitude values.
#' @param digits  is the number of digits in the output.
#'
#' @return
#'
#' @examples
#' \dontrun{}
#'
#' @export
#' @rdname DD2DMS
#'
DD2DMS<-function(lon=NULL,lat=NULL,digits=2){
		
	############ AUTHOR(S): ############
	# Arne Johannes Holmin
	############ LANGUAGE: #############
	# English
	############### LOG: ###############
	# Start: 2013-06-20 - Clean version.
	########## DEPENDENCIES: ###########
	#
	########### DESCRIPTION: ###########
	# Simple function converting from decimal degrees to degrees, minutes and seconds:
	############ VARIABLES: ############
	# ---lon--- is the vector of longitude values.
	# ---lat--- is the vector of latitude values.
	# ---digits--- is the number of digits in the output.
	
	
	##################################################
	##################################################
	##### Preparation #####
	# Longitude:
	east=lon>0
	lon=abs(lon)
	D_lon=floor(lon)
	M_lon=floor((lon-D_lon)*60)
	S_lon=round((lon-D_lon-M_lon/60)*3600,digits=digits)
	# Latitude:
	north=lat>0
	lat=abs(lat)
	D_lat=floor(lat)
	M_lat=floor((lat-D_lat)*60)
	S_lat=round((lat-D_lat-M_lat/60)*3600,digits=digits)
	
	
	##### Execution and output #####
	#if(numt>1){
	#	paste("Lon (first): ", expression(degree), D_lon, "  ", M_lon, "' ", S_lon, "'' ", c("W","E")[east+1], ",  Lat (first): ", D_lat, "  ", M_lat, "' ", S_lat, "'' ", c("S","N")[north+1],sep="",collapse="")
	#	}
	#else{
	paste("Lon: ", D_lon, "  ", M_lon, "' ", S_lon, "'' ", c("W","E")[east+1], ",  Lat: ", D_lat, "  ", M_lat, "' ", S_lat, "'' ", c("S","N")[north+1],sep="",collapse="")
	#	}
	##################################################
	##################################################
	}
