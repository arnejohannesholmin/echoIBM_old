#*********************************************
#*********************************************
#' Returning TRUE at all odd values and all decimal values.
#'
#' @param x  is the R-object to be checked for odd values.
#'
#' @return
#'
#' @examples
#' \dontrun{}
#'
#' @export
#' @rdname odd
#'
odd<-function(x){
	
	############ AUTHOR(S): ############
	# Arne Johannes Holmin
	############ LANGUAGE: #############
	# English
	############### LOG: ###############
	# Start: 2008-11-14 - Clean version.
	########### DESCRIPTION: ###########
	# Returning TRUE at all odd values and all decimal values.
	########## DEPENDENCIES: ###########
	#
	############ VARIABLES: ############
	# ---x--- is the R-object to be checked for odd values.
	
	
	##################################################
	##################################################
	as.logical(x%%2)
	##################################################
	##################################################
	}
