#*********************************************
#*********************************************
#' Transforms 'ftim' in the TSD file format to UTC matlab time.
#'
#' @param x  are the input time points given as 'ftim' in the TSD file format.
#' @param ...  added to avoid the error "unused argument" in mtim.TSD().
#'
#' @return
#'
#' @examples
#' \dontrun{}
#'
#' @export
#' @rdname ftim2mtim
#'
ftim2mtim<-function(x, ...){
	
	############ AUTHOR(S): ############
	# Arne Johannes Holmin
	############ LANGUAGE: #############
	# English
	############### LOG: ###############
	# Start: 2010-01-30 - Clean version.
	########### DESCRIPTION: ###########
	# Transforms 'ftim' in the TSD file format to UTC matlab time.
	########## DEPENDENCIES: ###########
	#
	############ VARIABLES: ############
	# ---x--- are the input time points given as 'ftim' in the TSD file format.
	# ---...--- added to avoid the error "unused argument" in mtim.TSD().
	
	
	##################################################
	##################################################
	##### Preparation #####
	temp = ftim2list(x,...)
	
	
	##### Execution and output #####
	1 + temp$y*365 + temp$cly[temp$y] + temp$d + temp$ly[temp$y+1]*(temp$m>2) + temp$S/86400
	##################################################
	##################################################
	}
