#*********************************************
#*********************************************
#' Adds noise to an array of sv-values, given the noise data present in 'data'.
#'
#' @param sv  is an array dimension [lenb,numb] (or a vector of the same length) of sv-values.
#' @param noise  is a vector of character strings of length 2, specifying which types of noise to apply to the data:
#' @param data  is the list of beams inputs as returned from read.TSD. For the treatment of noise the following variables are required:
#' @param indt  is a the time point index used if 'noise' includes "hi", high intensity noise, which is time step specific.
#' @param parlist  is a list of input parameters to the noise generation method specified by 'noise'. Any variables present as named list elements in 'parlist' will override the defaults.
#'
#' @return
#'
#' @examples
#' \dontrun{}
#'
#' @importFrom sonR echoIBM.pdns
#' @importFrom TSD arr.ind2ind dim_all strff zeros
#'
#' @export
#' @rdname echoIBM.add.noise
#'
echoIBM.add.noise<-function(sv, noise=c("bg","pn","ms"), data=NULL, indt=NULL, parlist=list()){
	
	############ AUTHOR(S): ############
	# Arne Johannes Holmin
	############ LANGUAGE: #############
	# English
	############### LOG: ###############
	# Start: 2010-10-16 - First version.
	# Update: 2011-11-26 - Added the option of adding correlated exponential noise (noise="cex").
	# Update: 2011-12-06 - Applied the exponential perturbation for each of "background noise", "close-range noise" and "signal", and summing afterwards, instead of adding all data first and applying the exponential perturbation afterwards.
	# Update: 2012-02-14 - Added the method echoIBM_rexp_MultSines() for generating correlated exponential/Barakat values.
	# Update: 2014-04-05 - Added "cpp" and "cap" in 'noise'.
	# Update: 2014-04-06 - Removed "nr_fun" in 'noise'.
	# Last: 2014-10-14 - Changed to draw exponential values only at the end.
	########### DESCRIPTION: ###########
	# Adds noise to an array of sv-values, given the noise data present in 'data'.
	########## DEPENDENCIES: ###########
	# zeros(), utim.TSD(), set.path(), echoIBM.oneping(), write.TSD(), echoIBM_rexp_Rearr()
	############ VARIABLES: ############
	# ---sv--- is an array dimension [lenb,numb] (or a vector of the same length) of sv-values.
	# ---noise--- is a vector of character strings of length 2, specifying which types of noise to apply to the data:
	##		"bg" - Background noise
	##		"pn" - Periodic noise
	##		"hi" - High intensity noise
	##		"nr", "np", "cp" - Close-range noise generated in passive mode.
	##		"na", "ca" - Close-range noise generated in active mode.
	##		"cpp", "cap" - Close-range noise in passive and active mode, respectively, given for a number of time steps (recycled if more time steps are requested than are present in the variable 'cnpM' or 'cnaM', for passive and active close range noise, respectively). The noise values 'cnaM' and 'cnpM' must be given with time steps along the last dimension, and either one dimension (along beams) or two dimensions (along beams and across beams) before the time step dimension.
	##		"ex" - Independent exponential noise due to acoustic interference (applied on the close-range noise / reverberation noise ("nr"), background noise ("bg") and the simulated echo)
	##		"acex", "aex", "cex" - Correlated exponential noise due to acoustic interference (applied on the close-range noise / reverberation noise ("nr"), background noise ("bg") and the simulated echo). Generated using the rearrangement method developed by Holmin and Tjøstheim, in which independent uniformly distributed variables are drawn, and rearranged so that among the next 'l' voxels of a vector, the voxel following position 'k' is chosen to resemble the k'th voxel. This method has the ability to include both autocorrelation along vectors and correlation between vectors, because the voxel following the k'th voxel can be chosen according to a proximity criterion to the k'th voxel in several vector simulatneously, given specific weights that result in correlation between vectors. Of cource this method of rearrangement is ad-hoc and limited in which autororrelation and correlation structures that are achievable
	##		"ms" - Multiple sine waves: In this noise generation method the process of superimposed sine waves that occur when multiple targets scatter sound back to the receiver, is mimiced in order to produce the randomness present in real acoustic data. This method is more time consuming and depend on the number of targets contributing to each voxel (constant in this function), the  length of the sound pulse (affecting the autocorrelation along vectors) and the overlap between neighboring vectors, whereas the number of sample points and the number of preiods of the sine waves for each voxel affect the accuracy of the noise simulation. An advantage of this method is that the non-rayleigh distribution occuring when the number of targets is low can be acheived, but generally, in the simulations the number of targets is chosen high to produce exponentially distributed acoustical intensity
	##		"phase", "psn3" - Indicates that the phase of the periodic noise should be extracted from the matrix of phase angles for each beam of each time step, 'pn3M'. If not given, the phase angles are extracted from the mean phase angle estimate 'pns3'.
	# ---data--- is the list of beams inputs as returned from read.TSD. For the treatment of noise the following variables are required:
	#		 For noise=="bg": 'lenb', 'numb', and 'bgns'
	#		 For noise=="pn": 'sint', 'lenb', 'pns1', 'pns2', 'pns3', 'acfq', 'harm', and 'bgns' or 'numb'
	#		 For noise=="hi": 'lenb', 'numb', 'freq', 'hins' and 'hini'
	#		 For noise=="nr","np","cp": 'nrnp', 'lenb', 'numb'
	#		 For noise=="na","ca": 'nrna', 'lenb', 'numb'
	#		 For noise=="cpp": 'cnpM'
	#		 For noise=="cap": 'cnaM'
	#		 For noise==""acex","aex","cex": 'rate','prob','l','buffer','esnm','rho','w','wC','luqf','numb','nuqf','Cind'	
	#		 For noise=="ms": 'L','N','P','esnm','olpn','w','scale'
	# ---indt--- is a the time point index used if 'noise' includes "hi", high intensity noise, which is time step specific.
	# ---parlist--- is a list of input parameters to the noise generation method specified by 'noise'. Any variables present as named list elements in 'parlist' will override the defaults.
	
	# The following parameters are returned in the list 'parlist':
	
	#  If noise="ms" (9 parameters):
	#		'J' is the number of sample intervals along the beams.
	#		'nuqf' is the number of fans comprising the system (typically >1 for a rectangular grid of beams).
	#		'luqf' is the number of beams in each fan.
	#		'L' is the number of targets pr voxel. Low values results in increasingly non-rayleigh presure and non-exponential intensity (which is what is returned).
	#		'N' is the number of sample points pr voxel. High values increases stability and accuracy in the simulated noise, but increases time demand of the function.
	#		'P' is the number of periods pr voxel, which should be a high enough number, but not too high, to ensure good performance of the funciton.
	#		'w' is the length of the sine waves in units of the time intervals constituting the voxels. The autocorrelation will depend on this value.
	#		'olpn' (for the noise) and 'olps' (for the signal) are eihter character strings specifying the type of default correlation structure, or vectors, matrices or arrays of overlap values, representing constant correlation for all voxels, variable correlation between beams, or variable correlation for all voxels. If given as a string, the following values are accepted (abbreviations alowed):
	#			- "const", for constant correlation for all voxels
	#			- "beams", for variable correlation between beams
	#			- "voxels", for variable correlation for all voxels
	#			- "pings", for variable correlation for all voxels, and variable phase for each time step, specified by the variable 'pn3M', which must be given in the input files.
	#  If noise="acex","aex","cex" (11 parameters):
	#		'J' is the number of sample intervals along the beams.
	#		'nuqf' is the number of fans comprising the system (typically >1 for a rectangular grid of beams).
	#		'luqf' is the number of beams in each fan.
	#		'rate' is the parameter in the exponential distribution.
	#		'prob' is the probability values assigned to each of the consecutive values sorted by their proximity to the prevoius value. If w = 3 and prob = [0.7,0.5,0,5] the closest value will be assigned to the current position with probability 0.7, and if this fails, the second closest value will be assigned to the current position with probability 0.5, and so on.
	#		'l' is the number of values included when randomly rearranging the values not assigned to the current position. We may include more values than 'w' too reduce the effect of nevative autocorrelation at lags ≈ 5.
	#		'rho' is a vector of "correlation" values defining the dependence of a vector to its neighbor vectors on both sides in the horizontal direction. The reference vector is in the middle of 'rho' (usually having value 1) and the length of 'rho' must be odd.
	#		'w' is the number of consecutive values including the present value. If w=2, the method choses between the current and the next value depending on the proximity to the prevoius values.
	#		'wC' is the number of significant vectors correlated to each vector, used to deduce Cind. Must be an odd number!!!
	#		'C' is the number of consecutive values including the present value. If w=2, the method choses between the current and the next value depending on the proximity to the prevoius values.
	#		'Cind' is an optional matrix of index values for the significant correlation values of C for each row. This is used in runif_Rearr.cpp to ease computation, and should indicate c++ indexes starting from 0 instead of 1 as in R. Negative values of values >= p are ignored in runif_Rearr.cpp.
	#		'buffer' is a value used in the function rexp_Rearr.R to avoid a strange error in the c++ function of the same name.
	
	
	##################################################
	##################################################
	########## Preparation ##########
	printt(indt)
	if(sum(nchar(noise))==0){
		sv
		}
	# Function used for adding exponential independent or correlated noise:
	addex <- function(sv, noise, indt, parlist){
		# Treat the seed so that if NULL is given draw random seeds, if 'indt' is given pick out the indt'th seed, and otherwise use the first element: 
		if(any(c("ms", "ex", "bk") %in% noise)){
			if(is.null(parlist$seed)){
				parlist$seed <- runif(1, 0, 1e9)
				}
			# If indt is given (as a single integer), pick out the indt'th seed value:
			else if(length(indt)){
				parlist$seed <- parlist$seed[indt]
			}
			# Set the seed:
			set.seed(parlist$seed[1])
		}
		
		# Add correlated exponential noise by multiple sines:
		if(any(c("ms") %in% noise)){
			# Define the overlap array if the phase angles are different for each time step:
			if("pn" %in% noise && is.character(parlist$olpn) && strff("p", parlist$olpn)){
				parlist$olpn <- echoIBM.olpt(data, indt=indt)$olpt
				dim(parlist$olpn) <- c(dim(parlist$olpn)[1:2], parlist$luqf, parlist$nuqf)
				}
			# Set the dimension of the data to a matrix of beams along the columns, and sum over rows and select the rows that have sum > 0, and expand to one row on either side of the selected rows. Do this to save CPU time:
			dim(sv) <- c(parlist$J, parlist$luqf * parlist$nuqf)
			valid <- which(rowSums(sv) > 0)
			if(length(valid)>0){
				valid <- seq(max(1,min(valid)-1), min(parlist$J,max(valid,na.rm=TRUE)+1))
				# Redefine the number of samples along beams:
				parlist$J <- length(valid)
				#thisexp <- echoIBM_rexp_MultSines(parlist)$noise^(1/1.6) / gamma(1+1/1.6)
				thisexp <- echoIBM_rexp_MultSines(parlist)$noise
				#Apply the exponent 'Wshp' to the exponentially distributed variables to obtain Weibull distributed variables:
				#thisexp[,451:475] <- thisexp[,451:475]^(1/1.5) / gamma(1+1/1.5)
				#thisexp <- thisexp^parlist$Wshp[seq_len(parlist$J),] / gamma(1+1/parlist$Wshp[seq_len(parlist$J),])
				
				# Insert the exponentially distributed values in the correct rows:
				sv[valid,] <- sv[valid,]*thisexp
				}
			
			#thisexp <- echoIBM_rexp_MultSines(parlist)$noise
			#sv <- sv*thisexp
			}
		# Add correlated exponential noise by rearrangement method:
		#else if(any(c("acex","aex","cex") %in% noise)){
		#	if("ex" %in% noise){
		#		warning("Correlated exponential noise simulated (not independent exponential noise as indicated by noise = \"ex\")")
		#		}
		#	parlist$rate <- 1/c(sv)
		#	sv <- echoIBM_rexp_Rearr(parlist)
		#	}
		# Add independent exponential noise:
		else if("ex" %in% noise){
			# Draw from the exponential distribution:
			sv <- rexp(max(data$lenb)*data$numb, 1/c(sv))
			dim(sv) <- c(max(data$lenb), data$numb)
			}
		else if("bk" %in% noise){
			# Draw from the exponential distribution:
			sv <- rexp(max(data$lenb)*data$numb, 1/c(sv))
			# Apply the Barakat distribution:
			if(length(parlist$Brkt)>0){
				sv[parlist$Brkt] <- rBarakatI(length(parlist$Brkt), nsig=parlist$nsig, magn=sv[parlist$Brkt]/parlist$nsig, N=parlist$N, max.memory=parlist$max.memory)
				}
			dim(sv) <- c(max(data$lenb), data$numb)
			}
		sv
		}
	# If parlist is not given, it is extracted from the method of generating defaults:
	if(length(parlist)==0){
		warning("'parlist' not given and was defaulted using echoIBM_rexp_defaults()")
		parlist <- echoIBM_rexp_defaults(noise=noise, data=data, parlist=parlist)
		}
			
	
	########## Execution ##########
	# Define the expected value of the noise in each voxel:
	beta <- zeros(dim_all(sv))
	
	### (1) Add background noise: ###
	if("bg" %in% noise){
		if(is.null(data$bgns)){
			warning("Background noise data 'bgns' missing. To generate noise data use get.bgns()")
			}
		else{
			# Add background noise to the output:
			beta <- beta + matrix(data$bgns, nrow=max(data$lenb), ncol=data$numb, byrow=TRUE)
			}
		}	
	
	
	### (2) Add periodic noise: ###
	if("pn" %in% noise){
		pdns.present <- all(length(data$sint)>0, length(data$lenb)>0, length(data$pns1)>0, length(data$pns2)>0, length(data$pns3)>0, length(data$acfq)>0, length(data$harm)>0) & (length(data$bgns)>0 | length(data$numb)>0)
		if(!pdns.present){
			warning("Periodic noise data missing. To generate noise data use get.bgns.MS70()")
			}
		else{
			# Add periodic noise to the output:
			if(is.character(parlist$olpn) && strff("p", parlist$olpn)){
				beta <- beta + echoIBM.pdns(data, indt=indt, TVG=FALSE)$pdns
				}
			else if(strff("ek60",data$esnm[1])){
				beta <- beta + echoIBM.pdns(data, indt=NULL, TVG=FALSE)$pdns
				}
			else{
				beta <- beta + echoIBM.pdns(data, indt=NULL, TVG=FALSE)$pdns
				}
			}
		}	
	
	
	### (3) Add high intensity noise: ###
	if("hi" %in% noise){
		# Error if one of 'numb', 'freq' or "lenb" is missing:
		if(any(length(data$numb)==0, length(data$lenb)==0)){
			stop("'numb' and 'lenb' must be present for high intensity noise to be added")
			}
		# Add high intensity noise if present:
		if(all(length(data$hins)>0, length(data$hini)>0)){
			warning("High intensity noise data missing. To generate noise data use get.hins.MS70()")
			}
		else{
			# If 'indt' is missing, choose the first time step that has high intensity noise:
			if(length(indt)==0){
				indt <- min(data$hini[,3])
				}
			theseindt <- data$hini[,3]==indt
			theseind <- arr.ind2ind(data$hini[theseindt,1:2], c(max(data$lenb),data$numb))
			# Add high intensity noise to the output:
			beta[theseind] <- beta[theseind]+data$hins[theseindt]
			}
		}	
	
	
	### (4) Add close-range passive noise: ###
	if(any(c("nr", "np", "cp") %in% noise)){
		if(is.null(data$nr0p)){
			warning("Close-range passive noise data 'nr0p' missing. To generate noise data use get.nrns.MS70()")
			}
		else{
			# Close-range noise may be given as a vector of one value for each sampling interval along the beams (with length equal to the length of the longest beam):
			if(length(dim(data$nr0p))!=2){
				data$nr0p <- matrix(data$nr0p, nrow=max(data$lenb), ncol=data$numb)
				}
			}
		}
	# Or as a matrix/array of time steps:
	else if("cpp" %in% noise){
		if(is.null(data$cnpM)){
			warning("Pingwise close-range passive noise data 'cnpM' missing.")
			}
		else{
			# Close-range noise may be given for each time step as a vector of one value for each sampling interval along the beams (with length equal to the length of the longest beam):
			dimcnpM <- dim(data$cnpM)
			# When 'cnpM' is given, it is assumed that the last dimenstion holds time steps:
			if(length(dimcnpM)==2){
				data$nr0p <- matrix(data$cnpM[,(indt-1) %% ddimcnpM[2] + 1], nrow=max(data$lenb), ncol=data$numb)
				}
			else if(length(dimcnpM)==3){
				data$nr0p <- data$cnpM[,,(indt-1) %% ddimcnpM[2] + 1]
				}
			else{
				warning("Wrong dimension of 'cnpM'. Should have dimension (length of beams, number of beams, number of pings) or (length of beams, number of pings)")
				}
			}
		}
	
	# Adjust the length of the near-range noise matrix and add close-range to the output::
	if(any(c("nr", "np", "cp", "cpp") %in% noise) && length(data$nr0p)>0){
		if(nrow(data$nr0p)<max(data$lenb)){
			data$nr0p <- rbind(data$nr0p, zeros(max(data$lenb)-nrow(data$nr0p), data$numb))
			}
		else{
			data$nr0p <- data$nr0p[1:max(data$lenb),]
			}
		beta <- beta+data$nr0p
		}
	
	
	### (5) Add close-range passive noise: ###
	if(any(c("na", "ca") %in% noise)){
		if(is.null(data$nr0a)){
			warning("Close-range active noise data 'nr0a' missing. To generate noise data use get.nrns.MS70()")
			}
		else{
			# Close-range noise may be given as a vector of one value for each sampling interval along the beams (with length equal to the length of the longest beam):
			if(length(dim(data$nr0a))!=2){
				data$nr0a <- matrix(data$nr0a, nrow=max(data$lenb), ncol=data$numb)
				}
			}
		}
	# Or as a matrix/array of time steps:
	else if("cap" %in% noise){
		if(is.null(data$cnaM)){
			warning("Pingwise close-range active noise data 'cnaM' missing.")
			}
		else{
			# Close-range noise may be given for each time step as a vector of one value for each sampling interval along the beams (with length equal to the length of the longest beam):
			# When 'cnaM' is given, it is assumed that the last dimenstion holds time steps:
			dimcnaM <- dim(data$cnaM)
			if(length(dimcnaM)==2){
				data$nr0a <- matrix(data$cnaM[,(indt-1) %% dimcnaM[2] + 1], nrow=max(data$lenb), ncol=data$numb)
				}
			else if(length(dimcnpM)==3){
				data$nr0a <- data$cnaM[,,(indt-1) %% dimcnaM[2] + 1]
				}
			else{
				warning("Wrong dimension of 'cnaM'. Should have dimension (length of beams, number of beams, number of pings) or (length of beams, number of pings)")
				}
			}
		}
	
	# Adjust the length of the near-range noise matrix and add close-range to the output:
	if(any(c("na", "ca", "cap") %in% noise) && length(data$nr0a)>0){
		if(NROW(data$nr0a)<max(data$lenb)){
			data$nr0a <- rbind(data$nr0a, zeros(max(data$lenb)-nrow(data$nr0a), data$numb))
			}
		else{
			data$nr0a <- data$nr0a[1:max(data$lenb),]
			}
		beta <- beta+data$nr0a
		}
	### (6) Do not run the Barakat PDF on noise: ###
	else if("bk" %in% noise){
		parlist$Brkt <- NULL
		}
	
	sv <- addex(sv=beta+sv, noise=noise, indt=indt, parlist=c(list(olp0=parlist$input_olpn),parlist))
	
	
	########## Output ##########
	sv
	##################################################
	##################################################
	}
