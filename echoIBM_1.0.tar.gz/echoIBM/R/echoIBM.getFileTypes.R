#*********************************************
#*********************************************
#' Reads the header of all files in an event and classifies into the following file types: beams (beam configuration), ctd, vessel, pings, school, tsd, other.
#'
#' @param event  is the path to the directory of the simulated files. If the length of 'event' is 2, the second string is the path to the temp-directory holding the files to merge, while the first is the directory in which to put the merged files.
#'
#' @return
#'
#' @examples
#' \dontrun{}
#'
#' @importFrom tools file_ext
#'
#' @export
#' @rdname echoIBM.getFileTypes
#'
echoIBM.getFileTypes <- function(files, ext=c("beams", "ctd", "pings", "school", "tsd", "vessel"), key=list(), recursive=TRUE){
	# Get the files, if 'files' is a directory:
	if(length(files)==1 && isTRUE(file.info(files)$isdir)){
		files <- list.files(event, recursive=recursive, full.names=TRUE)
	}
	# Read variable names and file extensions:
	suppressWarnings(labl <- lapply(files, function(x) read.TSD(x, header=TRUE, var=NULL)$labl))
	filesext <- tools::file_ext(files)
	
	# Get the indices at each file extension:
	ind <- lapply(ext, function(x) which(filesext==x | unlist(lapply(labl, function(y) any(y %in% key[[x]])))))
	names(ind) <- ext
	
	# And the files with extension that are not included in 'ext':
	ind <- c(ind, list(other=which(!ext %in% ext)))
	# Return the files:
	lapply(ind, function(x) files[x])
}
