#*********************************************
#*********************************************
#' Calls the function rexp_Rearr(), which generates correlated vectors of autocorrelated exponential variables. Paramteres are set according to the information contained in 'data'.
#'
#' @param data  is a list of the required beam configuration information, including length 'lenb' of the beams, number 'numb' of beams and the frequency 'freq' of the beams, as well as the sonar/echosounder type 'esnm'.
#' @param parlist  is a list of input parameters:
#' @param data  is a list of beam configuration data, used to extract defaults if 'parlist' is not given.
#'
#' @return
#'
#' @examples
#' \dontrun{}
#'
#' @export
#' @rdname echoIBM_rexp_Rearr
#'
echoIBM_rexp_Rearr<-function(parlist=list(),data=list()){
	
	############ AUTHOR(S): ############
	# Arne Johannes Holmin
	############ LANGUAGE: #############
	# English
	############### LOG: ###############
	# Start: 2010-10-16 - First version.
	# Last: 2012-02-28 - Changed to using 'parlist' holding the parameters.
	########### DESCRIPTION: ###########
	# Calls the function rexp_Rearr(), which generates correlated vectors of autocorrelated exponential variables. Paramteres are set according to the information contained in 'data'.
	########## DEPENDENCIES: ###########
	# even(), rexp_Rearr()
	############ VARIABLES: ############
	# ---data--- is a list of the required beam configuration information, including length 'lenb' of the beams, number 'numb' of beams and the frequency 'freq' of the beams, as well as the sonar/echosounder type 'esnm'.
	# ---parlist--- is a list of input parameters:
	#		'J' is the number of sample intervals along the beams.
	#		'nuqf' is the number of fans comprising the system (typically >1 for a rectangular grid of beams).
	#		'luqf' is the number of beams in each fan.
	#		'rate' is the parameter in the exponential distribution.
	#		'prob' is the probability values assigned to each of the consecutive values sorted by their proximity to the prevoius value. If w = 3 and prob = [0.7,0.5,0,5] the closest value will be assigned to the current position with probability 0.7, and if this fails, the second closest value will be assigned to the current position with probability 0.5, and so on.
	#		'l' is the number of values included when randomly rearranging the values not assigned to the current position. We may include more values than 'w' too reduce the effect of nevative autocorrelation at lags ≈ 5.
	#		'rho' is a vector of "correlation" values defining the dependence of a vector to its neighbor vectors on both sides in the horizontal direction. The reference vector is in the middle of 'rho' (usually having value 1) and the length of 'rho' must be odd.
	#		'w' is the number of consecutive values including the present value. If w=2, the method choses between the current and the next value depending on the proximity to the prevoius values.
	#		'wC' is the number of significant vectors correlated to each vector, used to deduce Cind. Must be an odd number!!!
	#		'C' is the number of consecutive values including the present value. If w=2, the method choses between the current and the next value depending on the proximity to the prevoius values.
	#		'seed' is the random seed of the utilization of 'prob' in c++.
	#		'Cind' is an optional matrix of index values for the significant correlation values of C for each row. This is used in runif_Rearr.cpp to ease computation, and should indicate c++ indexes starting from 0 instead of 1 as in R. Negative values of values >= p are ignored in runif_Rearr.cpp.
	#		'buffer' is a value used in the function rexp_Rearr.R to avoid a strange error in the c++ function of the same name.
	# ---data--- is a list of beam configuration data, used to extract defaults if 'parlist' is not given.
	
	
	##################################################
	##################################################
	########## Preparation ##########
	# Defaults (see "Test of rexp_MultSines.R"). This combination is as far as the analysis established, the least time consuming combination resulting in sufficiently exponential variables:
	if(!any(c("L","N","P","cor","J","nuqf","luqf","rate","prob","l","rho","w","wC","C","Cind","buffer") %in% names(parlist))){
		parlist=echoIBM_rexp_defaults(noise="cex",data=data,parlist=parlist)
		}
	# Treat the seed so that if NULL is given, draw random seeds, else use the first element (The function rexp_Rearr() takes as input exactly one value for the seed): 
	if(is.null(parlist$seed)){
		parlist$seed=runif(1,0,1e9)
		}
	else{
		set.seed(parlist$seed[1])
		parlist$seed=parlist$seed[1]
		}
	
	
	########## Execution and output ##########
	rexp_Rearr(n=parlist$J, C=parlist$C, wC=parlist$wC, w=parlist$w, rate=parlist$rate, prob=parlist$prob, l=parlist$l, seed=parlist$seed, Cind=parlist$Cind, buffer=parlist$buffer)$X
	##################################################
	##################################################
	}
