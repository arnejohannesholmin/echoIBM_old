echoIBM_datasets_directory <- function(text=NULL){
	file = "echoIBM_datasets_directory.txt"
	extdata = file.path(find.package("echoIBM"), "extdata")
	file = file.path(extdata, file)
	if(length(text)>0 && nchar(text)>0){
		return(writeLines(text, file))
	}
	extdatafiles = list.files(extdata, full.names=TRUE)

	if(file %in% extdatafiles){
		readLines(file, warn=FALSE)
		}
	else{
		stop(paste0("The file \n\n", file, "\n\nmissing. Use \n\nechoIBM_datasets_directory(PATH_TO_DIRECTORY_HOLDING_ECHOIBM_PROJECTS_AND_RESOURCE_FILES) \n\nto set the path to the directory holding the echoIBM projects and resource files (such as \"~/Data/echoIBM\")"))
		}
	}
