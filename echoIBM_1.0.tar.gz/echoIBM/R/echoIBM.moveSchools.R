#*********************************************
#*********************************************
#' Calculates new positions of school specified compactly by the dynamic variables of the school as a whole, given time elapsed. 
#'
#' @return
#'
#' @examples
#' \dontrun{}
#'
#' @importFrom TSD sph2car
#'
#' @export
#' @rdname echoIBM.moveSchools
#' 
echoIBM.moveSchools=function(data,utim){
	timespan = utim - data$utmS
	xyz = cbind(data$psxS, data$psyS, data$pszS) + sph2car(cbind(timespan*data$aspS, data$thtS, data$phiS))
	data$psxS = xyz[,1]
	data$psyS = xyz[,2]
	data$pszS = xyz[,3]
	data
	}
