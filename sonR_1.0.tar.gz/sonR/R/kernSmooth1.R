#*********************************************
#*********************************************
#' (Usually Gaussian) smoothing an array along the first dimension.
#'
#' @param x  is an array to be smoothed along the first dimension.
#' @param kern  is the kernel of the smoothing filter, defaulted to a Gaussian kernel.
#' @param nsd  is the number of standard deviations on either side of the mean of the Gaussian kernel, outside which the kernel is zero.
#'
#' @return
#'
#' @examples
#' \dontrun{}
#'
#' @export
#' @rdname kernSmooth1
#'
kernSmooth1<-function(x,kern=3,nsd=3){
	
	############ AUTHOR(S): ############
	# Arne Johannes Holmin
	############ LANGUAGE: #############
	# English
	############### LOG: ###############
	# Start: 2012-11-23 - Clean version.
	########### DESCRIPTION: ###########
	# (Usually Gaussian) smoothing an array along the first dimension.
	########## DEPENDENCIES: ###########
	#
	############ VARIABLES: ############
	# ---x--- is an array to be smoothed along the first dimension.
	# ---kern--- is the kernel of the smoothing filter, defaulted to a Gaussian kernel.
	# ---nsd--- is the number of standard deviations on either side of the mean of the Gaussian kernel, outside which the kernel is zero.
	
	
	##################################################
	##################################################
	########## Preparation ##########
	# If the kernel is given as a single number, it is interpreted as the standard deviation of a Gaussian kernel:
	if(length(kern)==1){
		kern=dnorm(seq(floor(-kern*nsd),ceiling(kern*nsd)),sd=kern)
		kern=kern/sum(kern)
		}
	# Store the dimension of 'x', and convert to matrix:
	olddim=dim(x)
	if(length(olddim)==0){
		dim(x)=c(length(x),1)
		}
	else if(length(olddim)>2){
		dim(x)=c(olddim[1],prod(olddim[-1]))
		}
	numb=dim(x)[2]
	lenb=dim(x)[1]
	keep=(length(kern)+1)/2
	
	
	########## Execution ##########
	# Run through the columns and smooth:
	for(i in seq_len(numb)){
		whichnotNA=which(!is.na(x[,i]))
		if(any(diff(whichnotNA))>1){
			warning("Missing values should only be located at the beginning or end of the vectors")
			}
		x[whichnotNA,i]=convolve(x[whichnotNA,i],kern,type="o")[seq(keep,length.out=length(whichnotNA))]
		# At both ends, comvolve manually to avoid the effect of padding with zeros done by convolve():
		
		}
	
		
	########## Output ##########
	# Return the smoothed data with the original dimension:
	dim(x)=olddim
	x
	##################################################
	##################################################
	}
