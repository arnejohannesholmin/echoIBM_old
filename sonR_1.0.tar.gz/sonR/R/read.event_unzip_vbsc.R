#*********************************************
#*********************************************
#' Merges time steps of acoustic data located in the neighbor directory "temp" of the "tsd"-directory given by 'event'.
#'
#' @param event  is the path to the directory of the simulated files. If the length of 'event' is 2, the second string is the path to the temp-directory holding the files to merge, while the first is the directory in which to put the merged files.
#' @param t  is a vector of the numbers of the pings to be merged, as given in the simulation event. If t=="all", all time steps are merged.
#' @param beams  is the list of beams inputs as returned from read.TSD. For the treatment of noise the following variables are required:
#' @param x		is the list of ctd inputs as returned from read.TSD.
#' @param pad	Logical: if TRUE, pad with missing values to make the list elements fit in the dimension up to the last dimension.
#' @param split	Logical: if TRUE, split each list element to have last dimenstion equal to 1.
#'
#' @importFrom TSD mergeListKeepDimensions
#'
#' @export
#' @rdname read.event_unzip_vbsc
#'
read.event_unzip_vbsc <- function(x, pad=TRUE, split=TRUE, filename=NULL, t=NULL, fill=NA){
	# Filling in for compressed acoustic data:
	if(length(x$vbsc)>0 && length(x$vxIX)>0){
		# In the unlikely event that all time steps have equal number of positive voxels in the compressed mode, split into a list:
		if(!is.list(x$vbsc)){
			thisnumt = ncol(x$vbsc)
			x$vbsc = split(x$vbsc, rep(seq_len(thisnumt), each=length(thisnumt)/thisnumt))
			x$vxIX = split(x$vxIX, rep(seq_len(thisnumt), each=length(thisnumt)/thisnumt))
			#x$vbsc = as.data.frame(x$vbsc)
			#x$vxIX = as.data.frame(x$vxIX)
			}
		# Create a list of vbsc, where each ping is represented in each element of the list, and fill inn the non-empty values indicated by 'vxIX':
		#for(i in seq_along(x$vbsc)){
		numt <- length(x$vbsc)
		for(i in seq_len(numt)){
			#tempvbsc = NAs(max(x$lenb[,i]), x$numb[i])
			tempvbsc = array(fill, dim=c(max(x$lenb[,i]), x$numb[i]))
			# Use c() since 'lenb' and 'numb' are required to be arrays with time along last dimension, obtained using drop.out=FALSE in read.TSD()
			tempvbsc[c(x$vxIX[[i]])] = c(x$vbsc[[i]])
			x$vbsc[[i]] = tempvbsc
			}
		# Remove vxIX if present:
		x$vxIX <- NULL
	}
	else if(length(x$vbsc) == 0){
		warning(paste0(
			"Volume backscattering coefficient 'vbsc' not present and set to an array of NAs ", 
			if(length(filename)) paste0("in file ", filename), 
			if(length(t)) paste0(" for time ", paste(t, collapse=", "))
			)
		)
		numt <- length(x$utim)
		x$vbsc <- vector("list", numt)
		for(i in seq_len(numt)){
			x$vbsc[[i]] = NAs(max(x$lenb[,i]), x$numb[i])
		}
	}
	
	# Rearranging sv-values in a 3 dimensional array [lenb, numb, numt]:
	if(is.list(x$vbsc)){
		x$vbsc = lapply(x$vbsc, function(x) if(length(dim(x)) == 2) array(x, dim=c(dim(x),1)) else x)
		}
	# Check whether the dimensions of each time step are identical:
	if(is.list(x$vbsc)){
		x$vbsc = mergeListKeepDimensions(x$vbsc, pad=pad, split=split, add1=length(dim(x$vbsc[[1]])) == 2)
		}
	return(x)
}
