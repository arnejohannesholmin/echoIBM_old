Acoustics_datasets_directory <- function(text=NULL){
	file = "Acoustics_datasets_directory.txt"
	extdata = file.path(find.package("sonR"), "extdata")
	file = file.path(extdata, file)
	if(length(text)>0 && nchar(text)>0){
		return(writeLines(text, file))
	}
	extdatafiles = list.files(extdata, full.names=TRUE)
	
	if(file %in% extdatafiles){
		readLines(file, warn=FALSE)
		}
	else{
		stop(paste0("The file \n\n", file, "\n\nmissing. Use \n\nAcoustics_datasets_directory(PATH_TO_DIRECTORY_HOLDING_ACOUSTIC_DATA_READ_BY_THE_PACKAGE_sonR) \n\nto set the path to the directory holding resource files and acoustic data from cruises (such as \"~/Data/Acoustics\")"))
		}
	}
