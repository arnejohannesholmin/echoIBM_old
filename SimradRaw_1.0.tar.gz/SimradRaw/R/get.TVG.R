#*********************************************
#*********************************************
#' Calculate the Time Varied Gain function.
#'
#' @param beams  is the list of beams inputs including "lenb" (lengths of beams), "sint" (pulse length), "absr" (absorption coefficent of the beams) and "asps" (average speed of sound).
#' @param x  is the input acoustic data arranged in an array having the radial part along the first dimension, the beams along the second or second and third, and time steps and other optional dimensions along the last dimension (lenb,numb,numt).
#' @param linear  is TRUE if x is in linear volume backscatter values (sv) and FALSE if x is in logarithmic volume backscatter values (Sv).
#' @param TVG.exp  is the exponent of the eamotric spreading of the sound wave, theoretically 2 for Sv and 4 for TS.
#' @param delta  is used in Gavins work.
#' @param R0  is used in Gavins work, shifting the first voxel to be imaginarily placed inside of the sonar.
#'
#' @return
#'
#' @examples
#' \dontrun{}
#'
#' @export
#' @rdname get.TVG
#'
get.TVG<-function(beams, x=NULL, linear=TRUE, TVG.exp=2, raw=c(0,1), delta=1/4, R0=-3.5){
	
	############ AUTHOR(S): ############
	# Arne Johannes Holmin
	############ LANGUAGE: #############
	# English
	############### LOG: ###############
	# Start: 2014-04-02 - Clean version.
	########### DESCRIPTION: ###########
	# Calculate the Time Varied Gain function.
	########## DEPENDENCIES: ###########
	#
	############ VARIABLES: ############
	# ---beams--- is the list of beams inputs including "lenb" (lengths of beams), "sint" (pulse length), "absr" (absorption coefficent of the beams) and "asps" (average speed of sound).
	# ---x--- is the input acoustic data arranged in an array having the radial part along the first dimension, the beams along the second or second and third, and time steps and other optional dimensions along the last dimension (lenb,numb,numt).
	# ---linear--- is TRUE if x is in linear volume backscatter values (sv) and FALSE if x is in logarithmic volume backscatter values (Sv).
	# ---TVG.exp--- is the exponent of the eamotric spreading of the sound wave, theoretically 2 for Sv and 4 for TS.
	# ---delta--- is used in Gavins work.
	# ---R0--- is used in Gavins work, shifting the first voxel to be imaginarily placed inside of the sonar.
	
	
	##################################################
	##################################################
	##### Preparation #####
	if(is.list(x)){
		if(length(x$vbsc)>0){
			x=x$vbsc
			linear=TRUE
			}
		else if(length(x$mvbs)>0){
			x=x$mvbs
			linear=FALSE
			}
		}
	if(length(beams$lenb)==0){
		beams$lenb=dim(x)[1]
		}
	else{
		beams$lenb=max(beams$lenb, na.rm=TRUE)
		}
	if(length(beams$plsl)==0){
		beams$plsl = 0
		}
	# Get the ranges to the voxels:	
	if(length(beams$rres)==0){
		beams$rres = soundbeam_range(beams, pos="res")
		}
	r = soundbeam_range(beams, pos="mid", raw=raw, delta=delta, R0=R0)
	
	
	##### Execution and output #####
	# Apply the exponent if given in 'TVG.exp', defaulted to 20 log r, suitable for Sv:
	TVG = pmax(1, r^TVG.exp * 10^( outer(r, 2*beams$absr/10)))
	# Apply logarithm if requested:
	if(linear){
		TVG
		}
	else{
		10*log10(TVG)
		}
	##################################################
	##################################################
	}
