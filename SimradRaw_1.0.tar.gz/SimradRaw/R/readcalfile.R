#*********************************************
#*********************************************
#' Reads calibration files in the xml format used by LSSS.
#'
#' @return
#'
#' @examples
#' \dontrun{}
#'
#' @importFrom XML xmlParse xmlToList
#'
#' @export
#' @rdname readcalfile
#' 
readcalfile <- function(x){
	indata = xmlParse(file=x)
	indata <- xmlToList(indata)[[1]]
	indata$gain = matrix(as.numeric(unlist(indata$g)),ncol=4, byrow=TRUE)
	colnames(indata$gain) = names(indata$g[[1]])
	indata$sacr = matrix(as.numeric(unlist(indata$SA)),ncol=2, byrow=TRUE)
	colnames(indata$sacr) = names(indata$SA[[1]])
	indata$rofs = as.numeric(indata$.attrs["Ro"])
	indata$rdlt = strsplit(indata$.attrs["delta"], ",", fixed=TRUE)[[1]]
	indata$rdlt = as.data.frame(strsplit(indata$rdlt, ":", fixed=TRUE))
	indata
}
